# Шалгалтын тэмдэглэл

Огноо: 2026-10-18. Local macOS, Python 3.9.6, Node 26.7.0, npm 11.19.0. Bundled CBC solver тухайн машин дээр бодит MILP бодлого solve хийсэн. Хоосон scaffold/build-only шалгалт биш.

## Backend

```bash
npm test
# .venv/bin/python -m pytest -q
```

**83 backend test passed.** Тестүүд тусдаа temporary SQLite ашиглаж, seed JSON-г өөрчлөхгүй.

- 22 node/45 candidate integrity, OSRM provenance, unique undirected pairs.
- Prim: 21 edge, connected, 21 bridge, Kruskal reference-тэй total cost тэнцүү.
- MILP: connected, zero Tarjan bridge, CBC optimal certificate.
- 22 resilient edge **бүрийг** тусад нь remove хийж connectivity шалгасан.
- K4 graph-ийн бүх subset-аас minimum cost болон risk/pair-penalty objective-тэй тулгасан.
- Candidate tree/disconnected graph infeasibility.
- Олон seeded graph дээр өөрийн Tarjan == NetworkX bridge.
- Таван destination дээр A* length == Dijkstra length, propagation/equipment units.
- Haversine known unit, same-city zero RTT, unreachable null path.
- Disaster polyline segment intersection (endpoints гадна байсан ч дундуур гарсан нөхцөл).
- SRLG exact membership, before/after graph mutation байхгүй.
- Multiple cumulative cuts/reset semantics, reroute surviving-only.
- Concrete MST sl-029 failure: 5 хот unreachable, availability 77.27%.
- Concrete resilient sl-028 failure: connected ч UB max RTT 50 ms-ээс их.
- CAPEX terrain rates, metrics regression, theoretical 231 mesh links.
- API health, bootstrap, route validation, theoretical simulation restriction.
- SQLite create/update/delete, duplicates, connected-node coordinate protection, reference protection.
- NaN/infinity/bool/range validation, geometry endpoints, malformed geometry.
- Validated lengths require evidence, user-edited OSRM claims rejected.
- Fresh OSRM preview cache proof accepted, semicolon-separated URL coordinates correctly parsed.
- Explicit inventory reset confirmation, structured errors, mocked road-preview integration.

## Browser

```bash
cd frontend
npx playwright install chromium
cd ..
npm run test:browser
```

**9 browser tests passed** in development; production build дээр мөн **9 passed**.

1. Atlas map, 22 labels, computed 6,626.1 км/$122.23M, no page runtime errors.
2. Prim bridge cut → 77.3% UI display/2 components → reset.
3. MILP non-bridge cut →100% connectivity + actual surviving backup highlight.
4. Flood and shared corridor simultaneous failures.
5. A* route 420.916 км/5.00916 ms + theoretical mesh separation.
6. Risk objective solve, comparison data, actual optimal certificate/chart.
7. Inventory persisted edit + restore original value.
8. JSON download-ийн content-д actual certificate/edge count, CSV download.
9. 390px mobile menu/map/controls, no horizontal page overflow.

Production bundle шалгах:

```bash
npm run build
ATLAS_E2E_PRODUCTION=1 npm run test:browser
```

Final production browser run: **9 passed (28.3s)**. Bundle runtime дээр SVG class initialization-ийн асуудал илэрснийг засч дахин бүх 9 тестийг ажиллуулсан. Infinite reroute animation нь reduced-motion preference үед унтарна.

## Production build

```bash
npm run build
```

Strict TypeScript (`noUnusedLocals`, `noUnusedParameters`) болон Vite production bundle амжилттай. map/charts/motion/vendor chunks тусдаа, `frontend/dist` гарна. Нэг ч type error, build error байхгүй. Preview дээр browser suite ажиллуулсан нь зөвхөн compiler pass гэдгээс илүү runtime шалгалт.

## Live integration ба original preservation

- Public OSRM endpoint-д keyless HTTPS request хийж UB→Darkhan **226.657 км / 1,507 full geometry point** авсан. Local URL-SHA256 disk cache-д хадгалсан. Cache proof-тэй route-ийг temporary SQLite-д save хийж шалгасан. Snapshot-ийн 226.904 км утгыг overwrite хийгээгүй; шинэ query/map revision ялгаатай байж болно.
- Өмнөх FiberGuard defense audit-д бүртгэсэн **36 эх файлын SHA256**-тай тулгасан: **0 өөрчлөлт**. New application нь sibling `../steppelink-atlas`, FiberGuard-ийн дотор биш.
- Desktop screenshot болон 390px mobile screenshot-ийг хараад шалгасан. Base tile/font нь интернетээс ирдэг ч local outline болон road geometries өөрийн bundle/data-аас гарна.

## Reproducible benchmark

```bash
.venv/bin/python -m scripts.benchmark > /tmp/atlas-benchmark.json
```

Checked-in `docs/benchmark.json` нь solver certificate болон sl-028 failure-ийн бүтэн data. Runtime timestamp, geographic snapshot, objective weights өөрчлөгдөхгүй үед metrics ижил. MILP-ийн тэнцүү objective-тай solution байвал solver хувилбар/order өөр edge сонгож болох тул математик optimum-ийн утга ба feasibility-г илүү чухалчилна.

Эдгээр нь local academic quality checks; actual construction survey, telecom SLA certification, authentication penetration testing, production load testing хийгээгүй.
