# SteppeLink Atlas — техникийн тайлбар

## 1. Энэ хувилбарын судалгааны санаа

Нэг candidate өгөгдөл дээр хоёр өөр аргачлалын эдийн засаг, тасралтын зан төлөвийг харьцуулж болно. FiberGuard-ийн dark NOC, Kruskal + greedy augmentation, Dijkstra, JSON repository-оос ялгаатайгаар Atlas нь light atlas UI, Prim + exact MILP separation, A*, SQLite хэрэгжүүлсэн. Нийтлэг OSM data-гаа тусдаа цуглуулсан гэж мэдэгдэхгүй.

22 хот = Улаанбаатар + 21 аймгийн төв. 45 pair бол төлөвлөлтийн candidate; одоо байгаа кабелийн бүртгэл биш. Full Mesh-ийн 231 pair нь зөвхөн математик benchmark. Нэг undirected simple edge нь логик төгсгөлүүдийн нэг холбоос; geometry нь road-following alignment. Road geometry давхцвал graph edge өөр байсан ч физик эрсдэл нь давхцаж болно.

## 2. Application architecture

| Давхарга | Файл / функц | Ажил |
|---|---|---|
| Browser | `frontend/src/App.tsx` / `App` | topology, selected road/city, failure IDs, applied weights state |
| Map | `frontend/src/NetworkMap.tsx` / `NetworkMap` | [lat,lon] polyline, cities, hazard circle, reroute highlight |
| Inventory | `frontend/src/Inventory.tsx` / `Inventory` | forms, persistence, OSRM preview |
| API client | `frontend/src/api.ts` / `api<T>` | JSON request, structured error |
| HTTP | `backend/app.py` / `create_app` | validation, API, solver cache |
| Repository | `backend/atlas/store.py` / `Store` | sqlite transactions, independent seed/reset |
| Graph | `backend/atlas/planner.py` | graph, optimization, metrics, A* |
| Failure | `backend/atlas/simulation.py` | geometry event, connectivity, before/after, proposals |
| Road integration | `backend/atlas/roads.py` / `fetch_road` | OSRM HTTPS + disk cache |

`GET /api/bootstrap` нь SQLite snapshot болон 4 plan-ийг буцаана. Эх solve-ийн дараа `(revision, risk_weight, diversity_weight)` түлхүүрээр in-memory cache хэрэглэнэ. Inventory edit бүр revision нэмдэг; дараагийн request шинэ plan бодно. 12 cache entry-ээс хэтэрвэл clear хийнэ. Cache process-local, shared distributed cache биш.

Failure request-д яг ямар topology, applied weights, previous_failed болон шинэ event байгаа нь ил тод. Backend selected baseline-аас fresh NetworkX graph байгуулж, failed edge-үүдийг нэмэхгүй. Baseline dataset болон optimizer state-ийг mutation хийхгүй. Frontend refresh/reset simulation failure state-ийг цэвэрлэнэ. Нэг хэрэглэгчийн simulation-г сервер бусад хэрэглэгчид тараахгүй; хадгалах session API байхгүй.

SQLite route/node CRUD нь өөрийн `data/atlas.sqlite3`-г өөрчилнө. Seed JSON read-only. Foreign key, undirected duplicate, endpoints, finite numeric validation, reference UB хамгаалалт бий. Холбоостой node-ийн координатыг шууд өөрчлөхгүй. API нь local academic use; authentication/RBAC байхгүй.

## 3. Prim MST

Файл: `backend/atlas/planner.py`, функц: `prim_tree(nodes, edges)`.

`nx.minimum_spanning_tree(g, algorithm='prim', weight='cost_usd')`. Энэ нь Python дээр Prim-ийг шинээр гар аргаар бичсэн биш, NetworkX-ийн бодит implementation. Minimum нь **Σ cost**, Σ distance биш. Terrain rate ялгаатай тул хоёрыг адил гэж үзэхгүй. Connected graph-д tree-ийн edge тоо n−1 = 21. Tree-д edge бүр bridge. Prim-ийн weighted connected undirected graph дээрх MST баталгаа стандарт; graph disconnected бол explicit error.

## 4. Tarjan bridge

Файл: `backend/atlas/planner.py`, функц: `tarjan_bridges(g)`.

DFS-д vertex бүрд discovery time болон хамгийн бага буцаж хүрэх discovery time `low` хадгална. Tree edge u→v дээр `low[v] > discovery[u]` бол edge bridge. Parent edge-ийг буцаах edge гэж андуурахгүй. Disconnected component бүрт DFS эхлүүлнэ. Tarjan-ийн үндсэн traversal O(V+E), O(V) нэмэлт санах ой. Энэ хэрэгжилт deterministic report гаргахын тулд node/neighbour/bridge жагсаалтыг эрэмбэлдэг тул нийт sorting overhead нь O(V log V + Σ degree(v) log degree(v) + B log B), B нь bridge count. Parallel edge-ийг зориуд зөвшөөрөхгүй: inventory нь undirected duplicate pair-ийг хориглодог.

`tests/test_planner.py::test_tarjan_matches_networkx` олон seeded graph дээр NetworkX bridge-тэй тулгадаг.

## 5. 2-edge MILP, cut generation

Файл: `backend/atlas/planner.py`, функц: `survivable_plan()`.

Candidate бүрд binary `xₑ ∈ {0,1}`. Үндсэн зорилго:

```text
minimize Σ cₑ xₑ
subject to Σ(incident on v) xₑ ≥ 2    for every v
           Σ(e crosses S) xₑ ≥ 2     for every nonempty proper subset S
```

Бүх subset-ийг урьдчилан жагсаах нь exponential тул зөвхөн degree constraints-тай relaxation solve хийнэ. Disconnected component олдвол тэр component-ийн cut-ийг, connected боловч bridge байвал bridge салгасан partition-ийн cut-ийг нэмнэ. Complement cut давхар орохгүйгээр canonical key хадгална.

CBC optimum гэж буцаасан эсэхийг `model.status` болон `model.sol_status` **хоёулангаар** шалгана. Time-limited feasible incumbent-ийг optimal гэж зарлахгүй. Нийт 25 секундийн solver budget, хамгийн их 100 separation round. Candidate graph анхнаасаа disconnected/bridge-тэй бол 2-edge боломжгүй. 60 node/160 edge-ээс хэтэрвэл academic size limit error.

**Яагаад final optimum зөв бэ?** Нэмсэн cut бүр нь ямар ч feasible 2-edge graph-д зайлшгүй. Тиймээс relaxation-ийн minimum нь бүрэн бодлогын minimum-ээс их байж болохгүй. Relaxation-ийн optimal solution нь connected ба bridge-free болсон бол өөрөө бүрэн feasible. Ийм үед хоёр minimum тэнцэнэ. Энэ бол зарласан candidate graph, objective, solver-ийн numerical tolerance доторх global optimum; бодит инженерийн бүх боломжит замын global optimum биш. Мөн arbitrary user geometry-ийн физик feasibility-г шийдээгүй.

Эцэст нь edge бүрийг тусад нь remove хийж connectivity шалгана. `verified_single_cuts=true` certificate-д орно. Энэ бол MST-д greedy edge нэмэх augmentation биш: MST-ийн зарим edge-ийг бүхэлд нь өөр замаар солих эрхтэй survivable network design. Иймээс зөвхөн нэрийг нь өөрчилсөн ижил алгоритм гэж тайлбарлахгүй.

Seed-ийн cost plan: 4 solve round, 5 cut. Эхэнд 3 disconnected cycle, дараа 2 component, эцэст 1 component/0 bridge. 22 node, 22 edge, degree ≥2 тул connected cycle үүссэн. Хамгийн бага edge тоотой энэ шийдэл нь ганц тасралтын connectivity-г хангадаг ч backup зам урт байна.

### Risk objective

```text
rₑ = 0.6 × risk_scoreₑ + 0.4 × disaster_exposureₑ
min Σ cₑ(1 + λrₑ)xₑ + μ Σ same-SRLG pairs (i,j) min(cᵢ,cⱼ)yᵢⱼ
 yᵢⱼ ≥ xᵢ+xⱼ−1; yᵢⱼ ≤ xᵢ; yᵢⱼ ≤ xⱼ
```

Ингэснээр `y=xᵢ AND xⱼ`. Pair penalty нь ижил SRLG-тай хоёр зам сонгосны корреляцийн proxy. Objective коэффициентүүдийг million USD болгон scale хийдэг. λ,μ dimensionless preferences; risk_score/exposure нь probability биш. UI үндсэн CAPEX коэффициентийг 1 гэж тогтоосон; backup latency болон terrain risk-ийг тусдаа user-controlled constraint болгож оруулаагүй (terrain CAPEX, assigned risk дотор дам туссан).

Default λ=1.5, μ=0.4 дээр **cost plan-тай яг ижил 22 edge** сонгосон. Шинэ сүлжээ мэт дүрсэлж тоо өөрчлөөгүй. Risk optimum нь declared weighted objective-ийн optimum; geographic disaster survival-ийг constraint болгож хангаагүй. Same-SRLG pairs торгох нь hard geographic diversity баталгаа биш, нэмэлт географийн зам байхгүй үед асуудлыг шийдэхгүй.

Жижиг K4 graph-ийн бүх 64 subset-ийг enumerating хийж cost болон risk objective хоёрын minimum-тэй MILP-г тулгасан meaningful tests бий.

## 6. A* ба математик latency

Файл: `backend/atlas/planner.py`, функц: `route()`.

`nx.astar_path(... weight='distance_km')`. Default geodesic heuristic нь OSRM-ийн snap/rounding болон user input-аас шалтгаалан хэт том болж болзошгүй. Тиймээс:

```text
α = min(1, min over surviving edges [road_distance / endpoint_Haversine])
h(u,target) = α × Haversine(u,target)
```

Haversine-ийн triangle inequality ба edge бүрийн scaled lower bound-аас heuristic admissible/consistent. Хэт бага heuristic нь хурдыг багасгаж болох ч shortest length-ийн зөв байдлыг алдагдуулахгүй. Empty edge set-д α=1; no-path үр дүн null distance/latency, empty node/edge list. Same source=target үед zero distance/hops/delay.

```text
propagation one-way ms = D_km / 200
propagation RTT ms     = 2 × D_km / 200
equipment one-way ms   = H × 0.2
modeled RTT ms         = 2 × (D_km / 200 + H × 0.2)
```

200,000 км/с = 200 км/ms. Замын урт болон hops суррогат; router load, queue, splice, protocol, amplifier engineering, dispersion, actual transceivers хэмжээгүй. Зам сонгох зорилго нь урт; equipment өөр учраас minimum RTT path гэсэн тусдаа баталгаа байхгүй. Topology max RTT нь бүх n(n−1)/2 pair-ийн distance-shortest замын modeled RTT maximum. Simulation max RTT нь **UB→бусад хот**-ын reachable routes-ийн maximum; unreachable city байвал 50 ms condition false, reachability-г нууж maximum бага гэж амлахгүй.

## 7. Disaster simulation

Файлууд: `simulation.py::disaster_ids`, `simulate`, `geography.py::intersects_circle`.

- Cut: сонгосон topology-д байгаа ID-ууд.
- Multiple failure: previous_failed ∪ new_event_ids.
- Flood/earthquake: effective_radius = radius × severity. Road polyline-ийн дурын segment нь тойрогтой intersect бол failed. Node өөрөө remove хийхгүй; incident roads нь огтлолын улмаас тасарч болно.
- SRLG: тохирох shared_risk_group-ийн бүх selected edge failed.

Intersection нь center-ийн latitude дээрх equirectangular local plane-д segment-to-point distance. Endpoints outside ч segment тойрог дундуур гарвал олно. Газрын бөмбөрцгийн curvature, polygon flood extents, intensity attenuation, bridge/building vulnerability-гүй. Region radius томрох тусам approximation error өснө. Seed polyline-ийн simplification (20 м) intersection boundary-д нөлөөлж болно. Нэг жижиг хэсэг өртөхөд edge-ийг бүхэлд нь unusable болгох conservative binary model.

`simulate()` нь fresh surviving graph-оос connected components, UB reachable nodes, rerouted destination-ууд, after-path distance/latency гаргана. Affected city гэдэг нь UB-тэй холбоо тасарсан хот. Rerouted гэдэг нь after reachable бөгөөд edge sequence нь before sequence-ээс өөр болсон маршрут. Alternate route зөвхөн surviving selected edges ашиглана; unselected candidate замыг үнэгүй ашиглахгүй.

Availability = |UB component| / |all nodes| ×100. Demand-weighted availability = reachable non-UB demand / total non-UB demand ×100. Demand нь given weight; traffic capacity, actual packet flow, service degradation throughput биш.

Scenario-bank metric: selected edge-ийн SRLG тус бүрийг fail хийх + dataset order-ийн node[::4] бүрийн 65 км circle. Хоосон impact-тай scenario-г тооцохгүй. Бүтэн сүлжээ connected үлдсэн scenario / бүх counted scenario. Seed дээр 10, survival 0%. Topology-ууд өөр impacted route-тэй байж болно, энэ нь ижил weather observation-based dataset биш. Mesh row-ийн scenario statistic-ийг физик тэсвэр гэж тайлбарлахгүй; UI тодорхой theoretical label тавьсан.

## 8. Recovery strategy

`backend/atlas/simulation.py::recovery`.

Component бүрийг нэг supernode болгоно. Өөр component-ийг холбож чадах candidate route бүрт full modeled CAPEX тавина; нэг component pair-ийн parallel candidate-аас cheapest-ийг үлдээнэ. Failed selected edge бол restore, unselected candidate бол build. Component graph-д Prim MST/forest бодож холбоход шаардагдах санал гаргана.

Санал нь surviving graph-д apply болохгүй. Connected биш бол A* хүрэхгүй гэж хэвээр харуулна. Repair quote байхгүй тул бүтэн replacement CAPEX ашигласан, энэ нь засварын бодит үнэ биш. Active hazard доторх restore/build-ийг geographic feasibility constraint-ээр хориглоогүй; ажил гүйцэтгэхийн өмнө hazard clearance/survey хэрэгтэйг UI хэлнэ. Бүх candidate-ээр ч холбогдохгүй бол `can_reconnect=false`. Энэ санал connectivity-г л сэргээхээр тооцдог; дахин 2-edge болгох баталгаа биш.

## 9. Dataset, route geometry, provenance

OSRM route хүсэлтийн source/target нь lon,lat; response GeoJSON нь lon,lat. Map/domain нь lat,lon тул adapter солиж хадгална. OSRM length нь fastest driving route-ийн scalar distance; хамгийн богино машин зам/асфальт зам гэсэн баталгаа биш. Road surface ба cable existence unverified metadata байдаг.

Snapshot scalar distances нь full road geometry-оос OSRM бодсон distance. UI дахь simplification нь distance-ийн оронд polyline хэмжиж CAPEX/latency бодохгүй. Live adapter-ийн full geometry-г шууд cache-д хадгалдаг. Snapshot retrieval-ийн огноо, provider URL зэрэг routing metadata үлдсэн. Live route нь map data update болон query параметрээс шалтгаалан snapshot-аас өөр байж болно: 2026-10-18 live UB→Darkhan 226.657 км, snapshot нь 226.904 км; preview нь snapshot/SQLite-г автоматаар overwrite хийхгүй.

Cost/risk/demand/SRLG нь өөр provenance-тэй: эдгээрийг OSRM-ээс татсан гэж хэлэхгүй. Weighted risk score бол user study input. Validated route нь user-supplied evidence, independent certification биш. Inventory-д урт/geometry-г өөрчлөөд OSRM гэсэн provenance хэвээр үлдээхийг хориглодог; зөв cache-тай live preview эсвэл estimate/validated source хэрэгтэй.

## 10. Баталгааны хүрээ ба сайжруулалт

Тест нь MST properties, each single cut, exhaustive tiny MILP optimality, Tarjan agreement, A*==Dijkstra, exact circle rule, surviving reroutes, latency units, CAPEX rates, persistence/validation, browser flow-уудыг шалгана. Энэ нь deployed telecom system-ийн field validation биш.

Дараагийн бодит сайжруулалтууд: surveyed route lengths + geometry, physical overlap-based SRLG inference, traffic-capacity multicommodity flow, maximum backup latency constraints, hazard polygons/terrain raster, geographically independent corridors, asynchronous solver jobs/queue, user sessions/auth, multi-process rate limiter, certificate persistence, accessibility keyboard map alternatives. Одоогийн UI хот/замыг select/form-аар сонгох өөр замтай; бүх SVG edge keyboard focus-тай биш.
