import { defineConfig } from '@playwright/test'
import { fileURLToPath } from 'node:url'
const root = fileURLToPath(new URL('..', import.meta.url))
export default defineConfig({
  testDir: './e2e',
  fullyParallel: false,
  workers: 1,
  timeout: 45000,
  expect: { timeout: 12000 },
  use: {
    baseURL: 'http://127.0.0.1:5180',
    browserName: 'chromium',
    viewport: { width: 1440, height: 1100 },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
  webServer: [
    {
      command: '.venv/bin/python -m backend.app',
      cwd: root,
      url: 'http://127.0.0.1:5102/api/health',
      reuseExistingServer: !process.env.CI,
      timeout: 20000,
    },
    {
      command: process.env.ATLAS_E2E_PRODUCTION ? 'npm run preview' : 'npm run dev',
      url: 'http://127.0.0.1:5180',
      reuseExistingServer: !process.env.CI,
      timeout: 20000,
    },
  ],
})
