import { useEffect, useState } from 'react'
import {
  MapContainer,
  TileLayer,
  Polyline,
  CircleMarker,
  Tooltip,
  Circle,
  GeoJSON,
  ZoomControl,
  useMapEvents,
  useMap,
} from 'react-leaflet'
import type { GeoJsonObject } from 'geojson'
import { Crosshair, MapPin, Plus } from 'lucide-react'
import type { City, Road, Topology, Zone } from './types'

export const colors: Record<Topology, string> = {
  tree: '#bf6345',
  resilient: '#3c6592',
  risk: '#347b6c',
  mesh: '#829875',
}
export const titles: Record<Topology, string> = {
  tree: '01 / Prim MST',
  resilient: '02 / MILP 2-edge',
  risk: '03 / Эрсдэл + SRLG',
  mesh: '04 / Full Mesh',
}
function Interaction({ onCenter }: { onCenter?: (p: [number, number]) => void }) {
  useMapEvents({
    click(e) {
      onCenter?.([e.latlng.lat, e.latlng.lng])
    },
  })
  return null
}
function Focus({ city }: { city?: City }) {
  const map = useMap()
  useEffect(() => {
    if (city) map.flyTo([city.lat, city.lon], Math.max(map.getZoom(), 6), { duration: 0.6 })
  }, [city, map])
  return null
}
function Resize() {
  const map = useMap()
  useEffect(() => {
    const observer = new ResizeObserver(() => map.invalidateSize({ pan: false }))
    observer.observe(map.getContainer())
    return () => observer.disconnect()
  }, [map])
  return null
}
function Home() {
  const map = useMap()
  return (
    <button
      className="map-home icon-btn"
      title="Монгол орныг бүтнээр харах"
      aria-label="Монгол орныг бүтнээр харах"
      onClick={() =>
        map.fitBounds(
          [
            [41.5, 87],
            [52.5, 120],
          ],
          { padding: [20, 20] },
        )
      }
    >
      <Crosshair size={18} />
    </button>
  )
}
export default function NetworkMap({
  nodes,
  edges,
  topology,
  selected,
  failed,
  bridges,
  backup,
  zone,
  onSelect,
  onCity,
  onCenter,
  focus,
}: {
  nodes: City[]
  edges: Road[]
  topology: Topology
  selected?: string
  failed: string[]
  bridges: string[]
  backup: string[]
  zone?: Zone | null
  onSelect: (e: Road) => void
  onCity: (n: City) => void
  onCenter?: (p: [number, number]) => void
  focus?: City
}) {
  const [outline, setOutline] = useState<GeoJsonObject | null>(null)
  useEffect(() => {
    fetch('/mongolia.geojson')
      .then((r) => r.json())
      .then(setOutline)
      .catch(() => {})
  }, [])
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]))
  return (
    <div className={`network-map ${onCenter ? 'place-zone' : ''}`}>
      <MapContainer
        bounds={[
          [41.5, 87],
          [52.5, 120],
        ]}
        zoomControl={false}
        scrollWheelZoom
        className="leaflet-atlas"
        minZoom={3}
        maxZoom={14}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {outline && (
          <GeoJSON
            data={outline}
            style={{
              color: '#999888',
              weight: 1,
              fillColor: '#faf5e7',
              fillOpacity: 0.22,
              dashArray: '4 4',
              interactive: false,
            }}
          />
        )}
        {edges.map((e) => {
          const isFailed = failed.includes(e.id),
            isBackup = backup.includes(e.id),
            isSelected = selected === e.id,
            bridge = bridges.includes(e.id)
          return (
            <Polyline
              key={`${topology}-${e.id}-${isFailed}-${isBackup}`}
              positions={e.geometry}
              className={isFailed ? 'failed-line' : isBackup ? 'backup-line' : ''}
              pathOptions={{
                color: isFailed
                  ? '#b1433c'
                  : isBackup
                    ? '#e1a131'
                    : isSelected
                      ? '#1d2d44'
                      : colors[topology],
                weight: isFailed ? 3 : isSelected || isBackup ? 4.5 : topology === 'mesh' ? 1 : 2.5,
                opacity: topology === 'mesh' ? 0.35 : 0.9,
                dashArray: isFailed ? '7 6' : bridge ? '3 4' : undefined,
              }}
              eventHandlers={{
                click: (ev) => {
                  ev.originalEvent.stopPropagation()
                  onSelect(e)
                },
              }}
            >
              <Tooltip sticky>
                {byId[e.source]?.name_mn} ↔ {byId[e.target]?.name_mn}
                <br />
                {e.distance_km.toFixed(1)} км {isFailed ? '• ТАСАРСАН' : bridge ? '• BRIDGE' : ''}
              </Tooltip>
            </Polyline>
          )
        })}
        {zone && (
          <Circle
            center={zone.center}
            radius={zone.effective_radius_km * 1000}
            pathOptions={{
              color: '#b1433c',
              fillColor: '#c87852',
              fillOpacity: 0.15,
              weight: 1.5,
              dashArray: '6 5',
              interactive: false,
            }}
          />
        )}
        {nodes.map((n) => (
          <CircleMarker
            key={n.id}
            center={[n.lat, n.lon]}
            radius={n.id === 'ub' ? 7 : 4.5}
            pathOptions={{
              color: '#fdfbf5',
              weight: 2,
              fillColor: n.id === 'ub' ? '#263b53' : '#58655d',
              fillOpacity: 1,
            }}
            eventHandlers={{
              click: (ev) => {
                ev.originalEvent.stopPropagation()
                onCity(n)
              },
            }}
          >
            <Tooltip
              permanent
              direction="top"
              offset={[0, -4]}
              className={`city-label ${n.id === 'ub' ? 'capital' : ''}`}
            >
              {n.name_mn}
            </Tooltip>
          </CircleMarker>
        ))}
        <ZoomControl position="bottomright" />
        <Interaction onCenter={onCenter} />
        <Focus city={focus} />
        <Home />
        <Resize />
      </MapContainer>
      <div className="map-coordinate">
        <Plus size={12} /> 46°51′ N · 103°50′ E <span>МОНГОЛ УЛС</span>
      </div>
      {onCenter && (
        <div className="place-hint">
          <MapPin size={15} /> Газрын зураг дээр дарж голомтыг байрлуулна
        </div>
      )}
      <div className="map-legend">
        <span>
          <i style={{ background: colors[topology] }} /> Төлөвлөсөн зам
        </span>
        <span>
          <i className="dashed" /> Bridge / тасарсан
        </span>
        <span>
          <i style={{ background: '#e1a131' }} /> A* нөөц маршрут
        </span>
      </div>
    </div>
  )
}
