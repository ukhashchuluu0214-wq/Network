import { useState } from 'react'
import {
  Check,
  Download,
  LoaderCircle,
  Pencil,
  Plus,
  RotateCcw,
  Search,
  Trash2,
  X,
} from 'lucide-react'
import type { Bootstrap, City, Road } from './types'
import { api, download, money, num } from './api'

const newNode: City = {
  id: '',
  name_mn: '',
  name_en: '',
  province: '',
  lat: 47,
  lon: 104,
  node_type: 'regional',
  traffic_demand_mbps: 500,
}
const newRoad: Road = {
  id: '',
  source: 'ub',
  target: 'darkhan',
  distance_km: 1,
  cost_usd: 17500,
  terrain: 'steppe',
  risk_score: 0.4,
  disaster_exposure: 0.3,
  corridor_id: 'USER-CORRIDOR',
  shared_risk_group: null,
  geometry: [],
  distance_source: 'user_estimate',
  status: 'planned',
}

export default function Inventory({
  data,
  reload,
  onError,
}: {
  data: Bootstrap
  reload: () => Promise<void>
  onError: (s: string) => void
}) {
  const [kind, setKind] = useState<'routes' | 'nodes'>('routes')
  const [search, setSearch] = useState('')
  const [node, setNode] = useState<City | null>(null)
  const [road, setRoad] = useState<Road | null>(null)
  const [editing, setEditing] = useState(false)
  const [busy, setBusy] = useState(false)
  const [geometry, setGeometry] = useState('')
  const [localError, setLocalError] = useState('')
  const [roadNotice, setRoadNotice] = useState('')
  const cityName = (id: string) => data.nodes.find((n) => n.id === id)?.name_mn ?? id
  const close = () => {
    setNode(null)
    setRoad(null)
    setLocalError('')
    setRoadNotice('')
  }
  const edit = (item?: City | Road) => {
    setEditing(!!item)
    setLocalError('')
    setRoadNotice('')
    if (kind === 'nodes') {
      setNode(item ? ({ ...item } as City) : { ...newNode })
      setRoad(null)
    } else {
      const value = item ? ({ ...item } as Road) : { ...newRoad }
      setRoad(value)
      setGeometry(JSON.stringify(value.geometry))
      setNode(null)
    }
  }
  const save = async (event: React.FormEvent) => {
    event.preventDefault()
    setBusy(true)
    setLocalError('')
    try {
      const item = node ?? (road ? { ...road, geometry: JSON.parse(geometry) } : null)
      if (!item) return
      await api(`/inventory/${kind}${editing ? `/${item.id}` : ''}`, item, editing ? 'PUT' : 'POST')
      close()
      await reload()
    } catch (e) {
      setLocalError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }
  const remove = async (id: string) => {
    if (!window.confirm(`Зөвхөн шинэ Atlas өгөгдлөөс ${id}-г устгах уу?`)) return
    setBusy(true)
    try {
      await api(`/inventory/${kind}/${id}`, undefined, 'DELETE')
      await reload()
    } catch (e) {
      onError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }
  const preview = async () => {
    if (!road) return
    setBusy(true)
    setLocalError('')
    setRoadNotice('')
    try {
      const result = await api<
        Pick<Road, 'geometry' | 'distance_km' | 'distance_source' | 'routing'>
      >('/road-preview', { source: road.source, target: road.target })
      setRoad({ ...road, ...result })
      setGeometry(JSON.stringify(result.geometry))
      setRoadNotice(
        `${result.geometry.length} цэг / ${num(result.distance_km, 3)} км · ${result.routing?.cache_hit ? 'cache' : 'OSRM шинэ хүсэлт'}`,
      )
    } catch (e) {
      setLocalError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }
  const reset = async () => {
    if (
      !window.confirm(
        'Зөвхөн SteppeLink Atlas-ийн өөрчлөлтүүдийг арилгаж, эх snapshot-оос дахин сэргээх үү? FiberGuard-д нөлөөлөхгүй.',
      )
    )
      return
    setBusy(true)
    try {
      await api('/reset', { confirm: 'RESET_ATLAS' })
      await reload()
    } catch (e) {
      onError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }
  const patchRoad = <K extends keyof Road>(key: K, value: Road[K]) =>
    setRoad((r) => (r ? { ...r, [key]: value } : r))
  const patchNode = <K extends keyof City>(key: K, value: City[K]) =>
    setNode((n) => (n ? { ...n, [key]: value } : n))
  const filteredRoads = data.edges.filter((e) =>
    `${e.id} ${cityName(e.source)} ${cityName(e.target)} ${e.shared_risk_group}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  )
  const filteredNodes = data.nodes.filter((n) =>
    `${n.name_mn} ${n.name_en} ${n.province}`.toLowerCase().includes(search.toLowerCase()),
  )
  return (
    <>
      <div className="inventory-toolbar">
        <div className="segmented">
          <button
            className={kind === 'routes' ? 'active' : ''}
            onClick={() => {
              setKind('routes')
              close()
            }}
          >
            Замууд / {data.edges.length}
          </button>
          <button
            className={kind === 'nodes' ? 'active' : ''}
            onClick={() => {
              setKind('nodes')
              close()
            }}
          >
            Хот / {data.nodes.length}
          </button>
        </div>
        <div className="search-field">
          <Search size={16} />
          <input
            aria-label="Өгөгдөл хайх"
            placeholder="Нэр, ID, corridor хайх…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button
          className="btn"
          onClick={() =>
            download(
              'atlas-inventory.json',
              JSON.stringify(
                { nodes: data.nodes, edges: data.edges, metadata: data.metadata },
                null,
                2,
              ),
              'application/json',
            )
          }
        >
          <Download size={15} /> JSON
        </button>
        <button className="btn primary" onClick={() => edit()}>
          <Plus size={15} /> {kind === 'routes' ? 'Зам нэмэх' : 'Хот нэмэх'}
        </button>
      </div>
      <div className="notice">
        <Check size={15} />{' '}
        {data.edges.filter((e) => e.distance_source === 'osm_road_route').length} OSRM замын
        snapshot · авто зам дагасан төлөвлөлт. Асфальт болон бодит кабелийн баталгаа биш.
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            {kind === 'routes' ? (
              <tr>
                <th>ID / эх → төгсгөл</th>
                <th>Урт / км</th>
                <th>CAPEX</th>
                <th>Terrain</th>
                <th>Risk</th>
                <th>SRLG</th>
                <th>Гарал</th>
                <th>Үйлдэл</th>
              </tr>
            ) : (
              <tr>
                <th>Хот</th>
                <th>Аймаг</th>
                <th>Координат</th>
                <th>Төрөл</th>
                <th>Загварын эрэлт</th>
                <th>Үйлдэл</th>
              </tr>
            )}
          </thead>
          <tbody>
            {kind === 'routes'
              ? filteredRoads.map((e) => (
                  <tr key={e.id}>
                    <td>
                      <small className="muted">{e.id}</small>
                      <br />
                      {cityName(e.source)} → {cityName(e.target)}
                    </td>
                    <td>{num(e.distance_km, 2)}</td>
                    <td>{money(e.cost_usd)}</td>
                    <td>{e.terrain}</td>
                    <td>{e.risk_score.toFixed(2)}</td>
                    <td>{e.shared_risk_group ?? '—'}</td>
                    <td>
                      <span className="source-badge">
                        {e.distance_source === 'osm_road_route'
                          ? 'OSM road'
                          : e.distance_source === 'validated_route'
                            ? 'User validated'
                            : 'User estimate'}
                      </span>
                    </td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="icon-btn"
                          aria-label={`${e.id} засах`}
                          onClick={() => edit(e)}
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          className="icon-btn"
                          aria-label={`${e.id} устгах`}
                          disabled={busy}
                          onClick={() => void remove(e.id)}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              : filteredNodes.map((n) => (
                  <tr key={n.id}>
                    <td>
                      <b>{n.name_mn}</b>
                      <small className="block muted">
                        {n.name_en} / {n.id}
                      </small>
                    </td>
                    <td>{n.province}</td>
                    <td>
                      {n.lat.toFixed(3)}, {n.lon.toFixed(3)}
                    </td>
                    <td>{n.node_type}</td>
                    <td>{num(n.traffic_demand_mbps)} Mbps</td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="icon-btn"
                          aria-label={`${n.id} засах`}
                          onClick={() => edit(n)}
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          className="icon-btn"
                          aria-label={`${n.id} устгах`}
                          disabled={busy}
                          onClick={() => void remove(n.id)}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
          </tbody>
        </table>
        {!(kind === 'routes' ? filteredRoads : filteredNodes).length && (
          <p className="empty-table">Хайлтад тохирох өгөгдөл алга.</p>
        )}
      </div>
      <div className="inventory-footnote">
        <p>
          Баталгаажсан урт оруулахдаа <code>validated_route</code> төрөл, эх сурвалжийн тайлбар,
          замын [lat,lon] geometry оруулна. Зөвхөн хоёр төгсгөлийн шулууныг авто зам гэж нэрлэхгүй.
        </p>
        <button className="text-btn" disabled={busy} onClick={() => void reset()}>
          <RotateCcw size={14} /> Atlas өгөгдөл сэргээх
        </button>
      </div>
      {(node || road) && (
        <div className="modal-backdrop">
          <section
            className="modal paper"
            role="dialog"
            aria-modal="true"
            aria-label={editing ? 'Өгөгдөл засах' : 'Өгөгдөл нэмэх'}
          >
            <header>
              <div>
                <span className="eyebrow">SQLITE INVENTORY</span>
                <h2>
                  {editing
                    ? 'Өгөгдөл засах'
                    : kind === 'routes'
                      ? 'Candidate зам нэмэх'
                      : 'Шинэ хот нэмэх'}
                </h2>
              </div>
              <button className="icon-btn" aria-label="Цонх хаах" onClick={close}>
                <X size={20} />
              </button>
            </header>
            <form onSubmit={(event) => void save(event)}>
              {localError && (
                <div role="alert" className="notice danger">
                  {localError}
                </div>
              )}
              {node && (
                <div className="form-grid">
                  <label>
                    ID
                    <input
                      required
                      pattern="[a-zA-Z0-9_-]{1,50}"
                      value={node.id}
                      disabled={editing}
                      onChange={(e) => patchNode('id', e.target.value)}
                    />
                  </label>
                  <label>
                    Төрөл
                    <select
                      value={node.node_type}
                      onChange={(e) => patchNode('node_type', e.target.value as City['node_type'])}
                    >
                      <option value="regional">regional</option>
                      <option value="core">core</option>
                    </select>
                  </label>
                  {(['name_mn', 'name_en', 'province'] as const).map((k, i) => (
                    <label key={k}>
                      {['Монгол нэр', 'Англи нэр', 'Аймаг'][i]}
                      <input
                        required
                        value={node[k]}
                        onChange={(e) => patchNode(k, e.target.value)}
                      />
                    </label>
                  ))}
                  <label>
                    Эрэлт / Mbps
                    <input
                      type="number"
                      min="1"
                      max="1000000"
                      required
                      value={node.traffic_demand_mbps}
                      onChange={(e) => patchNode('traffic_demand_mbps', +e.target.value)}
                    />
                  </label>
                  <label>
                    Latitude
                    <input
                      type="number"
                      step="any"
                      min="40"
                      max="53"
                      required
                      value={node.lat}
                      onChange={(e) => patchNode('lat', +e.target.value)}
                    />
                  </label>
                  <label>
                    Longitude
                    <input
                      type="number"
                      step="any"
                      min="87"
                      max="121"
                      required
                      value={node.lon}
                      onChange={(e) => patchNode('lon', +e.target.value)}
                    />
                  </label>
                  <p className="fine-print span-two">
                    Холбоостой хотын байршлыг шилжүүлэхээс өмнө замуудыг устгана. Шинэ хот
                    холбоосгүй үед planner infeasible гэж зөв мэдээлнэ.
                  </p>
                </div>
              )}
              {road && (
                <>
                  <div className="form-grid">
                    <label>
                      ID
                      <input
                        required
                        disabled={editing}
                        pattern="[a-zA-Z0-9_-]{1,50}"
                        value={road.id}
                        onChange={(e) => patchRoad('id', e.target.value)}
                      />
                    </label>
                    <label>
                      Terrain
                      <select
                        value={road.terrain}
                        onChange={(e) => patchRoad('terrain', e.target.value)}
                      >
                        {Object.keys(data.settings.terrain_rates).map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </label>
                    {(['source', 'target'] as const).map((k, i) => (
                      <label key={k}>
                        {i === 0 ? 'Эхлэх хот' : 'Төгсөх хот'}
                        <select
                          disabled={editing}
                          value={road[k]}
                          onChange={(e) => patchRoad(k, e.target.value)}
                        >
                          {data.nodes.map((n) => (
                            <option key={n.id} value={n.id}>
                              {n.name_mn}
                            </option>
                          ))}
                        </select>
                      </label>
                    ))}
                    <label>
                      Замын урт / км
                      <input
                        required
                        type="number"
                        min=".01"
                        max="15000"
                        step=".001"
                        value={road.distance_km}
                        onChange={(e) => patchRoad('distance_km', +e.target.value)}
                      />
                    </label>
                    <label>
                      Distance source
                      <select
                        value={road.distance_source}
                        onChange={(e) => patchRoad('distance_source', e.target.value)}
                      >
                        <option value="user_estimate">user_estimate</option>
                        <option value="osm_road_route">osm_road_route</option>
                        <option value="validated_route">validated_route</option>
                      </select>
                    </label>
                    <label>
                      Risk score
                      <input
                        required
                        type="number"
                        min="0"
                        max="1"
                        step=".001"
                        value={road.risk_score}
                        onChange={(e) => patchRoad('risk_score', +e.target.value)}
                      />
                    </label>
                    <label>
                      Disaster exposure
                      <input
                        required
                        type="number"
                        min="0"
                        max="1"
                        step=".001"
                        value={road.disaster_exposure}
                        onChange={(e) => patchRoad('disaster_exposure', +e.target.value)}
                      />
                    </label>
                    <label>
                      Corridor ID
                      <input
                        required
                        value={road.corridor_id}
                        onChange={(e) => patchRoad('corridor_id', e.target.value)}
                      />
                    </label>
                    <label>
                      Shared risk group
                      <input
                        value={road.shared_risk_group ?? ''}
                        onChange={(e) => patchRoad('shared_risk_group', e.target.value || null)}
                      />
                    </label>
                    {road.distance_source === 'validated_route' && (
                      <label className="span-two">
                        Баталгаажуулсан эх сурвалж / тайлбар
                        <input
                          required
                          value={road.validation_note ?? ''}
                          onChange={(e) => patchRoad('validation_note', e.target.value)}
                        />
                      </label>
                    )}
                  </div>
                  <button
                    type="button"
                    className="btn full osrm-btn"
                    disabled={busy}
                    onClick={() => void preview()}
                  >
                    <Download size={15} /> OSRM-ээс авто замын geometry авах
                  </button>
                  {roadNotice && <p className="good-text">{roadNotice}</p>}
                  <label>
                    Geometry JSON · [latitude, longitude][]
                    <textarea
                      rows={4}
                      required
                      value={geometry}
                      onChange={(e) => setGeometry(e.target.value)}
                    />
                  </label>
                  <p className="fine-print">
                    OSRM хүсэлт интернет шаарддаг; амжилттай үр дүн локал cache-д хадгалагдана.
                    CAPEX сервер дээр урт × terrain тарифаар дахин бодогдоно.
                  </p>
                </>
              )}
              <footer>
                <button type="button" className="btn" onClick={close}>
                  Болих
                </button>
                <button className="btn primary" type="submit" disabled={busy}>
                  {busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}Хадгалах
                </button>
              </footer>
            </form>
          </section>
        </div>
      )}
    </>
  )
}
