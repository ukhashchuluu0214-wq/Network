export async function api<T>(path: string, data?: unknown, method?: string): Promise<T> {
  const response = await fetch(`/api${path}`, {
    method: method ?? (data === undefined ? 'GET' : 'POST'),
    headers: data === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: data === undefined ? undefined : JSON.stringify(data),
  })
  const json = await response.json()
  if (!response.ok) throw new Error(json.error?.message ?? `HTTP ${response.status}`)
  return json as T
}
export const num = (v: number | null | undefined, digits = 0) =>
  v == null ? '—' : new Intl.NumberFormat('en-US', { maximumFractionDigits: digits }).format(v)
export const money = (v: number) => `$${num(v / 1e6, 2)}M`
export function download(name: string, content: string, mime: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }))
  const a = document.createElement('a')
  a.href = url
  a.download = name
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1500)
}
