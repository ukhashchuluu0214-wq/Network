export type Topology = 'tree' | 'resilient' | 'risk' | 'mesh'
export type Page = 'atlas' | 'compare' | 'lab' | 'inventory' | 'reports'
export interface City {
  id: string
  name_mn: string
  name_en: string
  province: string
  lat: number
  lon: number
  node_type: 'core' | 'regional'
  traffic_demand_mbps: number
}
export interface Road {
  id: string
  source: string
  target: string
  distance_km: number
  cost_usd: number
  terrain: string
  risk_score: number
  disaster_exposure: number
  corridor_id: string
  shared_risk_group: string | null
  geometry: [number, number][]
  distance_source: string
  status: string
  validation_note?: string
  routing?: {
    fetched_at?: string
    cache_hit?: boolean
    request_url?: string
    surface_verified?: boolean
  }
}
export interface Metrics {
  node_count: number
  edge_count: number
  distance_km: number
  capex_usd: number
  bridge_count: number
  bridge_ids: string[]
  components: number
  single_survival_pct: number
  scenario_survival_pct: number | null
  scenario_count: number
  max_rtt_ms: number
  rtt_under_50: boolean
  corridor_diversity: number
  largest_srlg_links: number
  connected: boolean
  added_cost_pct: number | null
}
export interface Certificate {
  solver: string
  status: string
  global_optimum: boolean
  rounds: number
  cuts: number
  verified_single_cuts: boolean
  objective_musd: number
  risk_weight: number
  diversity_weight: number
  scope: string
  trace: {
    round: number
    objective_musd: number
    edges: number
    components: number
    bridges: number
    cuts_before: number
  }[]
}
export interface Plan {
  id: Topology
  title: string
  edge_ids: string[]
  metrics: Metrics | null
  certificate: Certificate | null
  feasible: boolean
  error?: string
  theoretical_edges?: Road[]
}
export type Plans = Record<Topology, Plan>
export interface Bootstrap {
  nodes: City[]
  edges: Road[]
  revision: number
  metadata: Record<string, unknown>
  plans: Plans
  settings: {
    equipment_ms_per_hop: number
    fiber_speed_km_s: number
    terrain_rates: Record<string, number>
    reference: string
  }
}
export interface Path {
  reachable: boolean
  nodes: string[]
  edge_ids: string[]
  distance_km: number | null
  propagation_one_way_ms: number | null
  propagation_rtt_ms: number | null
  equipment_one_way_ms: number | null
  modeled_rtt_ms: number | null
}
export interface RoutePair {
  before: Path
  after: Path
}
export interface Event {
  kind: 'cut' | 'flood' | 'earthquake' | 'srlg'
  edge_ids?: string[]
  center?: [number, number]
  radius_km?: number
  severity?: number
  group?: string
}
export interface Zone {
  kind: string
  center: [number, number]
  radius_km: number
  severity: number
  effective_radius_km: number
}
export interface Simulation {
  max_reference_rtt_before_ms: number
  max_reference_rtt_after_ms: number
  rtt_under_50: boolean
  failed_ids: string[]
  newly_impacted_ids: string[]
  zone: Zone | null
  components: string[][]
  component_count: number
  affected_nodes: string[]
  availability_pct: number
  demand_availability_pct: number
  rerouted_count: number
  bridge_ids: string[]
  connected: boolean
  routes: (RoutePair & { destination: string; rerouted: boolean; delta_rtt_ms: number | null })[]
  recovery: {
    proposals: { id: string; source: string; target: string; action: string; cost_usd: number }[]
    additional_capex_usd: number
    can_reconnect: boolean
    message: string
  }
}
