import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowDownToLine,
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  CircleAlert,
  Compass,
  Database,
  ExternalLink,
  GitBranch,
  LoaderCircle,
  Map,
  Menu,
  Network,
  Radio,
  RotateCcw,
  Scissors,
  ShieldCheck,
  SlidersHorizontal,
  X,
} from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as ChartTooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts'
import { api, download, money, num } from './api'
import type {
  Bootstrap,
  City,
  Event,
  Page,
  Plan,
  Plans,
  Road,
  RoutePair,
  Simulation,
  Topology,
  Zone,
} from './types'
import NetworkMap, { colors, titles } from './NetworkMap'
import Inventory from './Inventory'

const nav: { id: Page; title: string; icon: typeof Map }[] = [
  { id: 'atlas', title: 'Сүлжээний атлас', icon: Map },
  { id: 'compare', title: 'Хувилбарууд', icon: GitBranch },
  { id: 'lab', title: 'Эрсдэлийн лаборатори', icon: Radio },
  { id: 'inventory', title: 'Өгөгдлийн сан', icon: Database },
  { id: 'reports', title: 'Судалгааны тайлан', icon: BookOpen },
]
const order: Topology[] = ['tree', 'resilient', 'risk', 'mesh']
const failMessage = (e: unknown) => (e instanceof Error ? e.message : String(e))

export default function App() {
  const [data, setData] = useState<Bootstrap | null>(null)
  const [page, setPage] = useState<Page>('atlas')
  const [topology, setTopology] = useState<Topology>('resilient')
  const [road, setRoad] = useState<Road | null>(null)
  const [city, setCity] = useState<City | null>(null)
  const [simulation, setSimulation] = useState<Simulation | null>(null)
  const [path, setPath] = useState<RoutePair | null>(null)
  const [source, setSource] = useState('ub'),
    [target, setTarget] = useState('darkhan')
  const [busy, setBusy] = useState('Өгөгдөл ба оновчтой сүлжээг тооцоолж байна…')
  const [error, setError] = useState('')
  const [risk, setRisk] = useState(1.5),
    [diversity, setDiversity] = useState(0.4)
  const [applied, setApplied] = useState({ risk_weight: 1.5, diversity_weight: 0.4 })
  const [eventKind, setEventKind] = useState<Event['kind']>('flood')
  const [center, setCenter] = useState<[number, number]>([47.918, 106.917])
  const [radius, setRadius] = useState(80),
    [severity, setSeverity] = useState(1)
  const [group, setGroup] = useState('central-valley')
  const [mobile, setMobile] = useState(false)

  const load = useCallback(async () => {
    setBusy('Замын өгөгдөл ба solver-ийн үр дүнг уншиж байна…')
    setError('')
    try {
      setData(await api<Bootstrap>('/bootstrap'))
      setApplied({ risk_weight: 1.5, diversity_weight: 0.4 })
      setRisk(1.5)
      setDiversity(0.4)
      setSimulation(null)
      setPath(null)
      setRoad(null)
      setCity(null)
    } catch (e) {
      setError(failMessage(e))
    } finally {
      setBusy('')
    }
  }, [])
  useEffect(() => {
    void load()
  }, [load])
  const resetSimulation = () => {
    setSimulation(null)
    setPath(null)
  }
  const changeTopology = (t: Topology) => {
    setTopology(t)
    resetSimulation()
    setRoad(null)
    setCity(null)
  }
  const runSimulation = async (event: Event, previous = simulation?.failed_ids ?? []) => {
    if (topology === 'mesh') {
      setError('Full Mesh нь онолын benchmark. Бодит candidate сүлжээ сонгоно уу.')
      return
    }
    setBusy('Тасралт, A* маршрут, сэргээх стратегийг тооцоолж байна…')
    setError('')
    try {
      const result = await api<Simulation>('/failures', {
        topology,
        ...applied,
        event,
        previous_failed: previous,
      })
      setSimulation(result)
      const destination = result.routes.find((r) => r.destination === target)
      setPath(destination ?? null)
      setSource('ub')
    } catch (e) {
      setError(failMessage(e))
    } finally {
      setBusy('')
    }
  }
  const findRoute = async () => {
    setBusy('A* зам хайж байна…')
    setError('')
    try {
      setPath(
        await api<RoutePair>('/route', {
          topology,
          ...applied,
          source,
          target,
          failed_ids: simulation?.failed_ids ?? [],
        }),
      )
    } catch (e) {
      setError(failMessage(e))
    } finally {
      setBusy('')
    }
  }
  const optimize = async () => {
    setBusy('CBC solver оновчтой шийдлийг баталгаажуулж байна…')
    setError('')
    try {
      const response = await api<{ plans: Plans }>('/plan', {
        risk_weight: risk,
        diversity_weight: diversity,
      })
      setData((d) => (d ? { ...d, plans: response.plans } : d))
      setApplied({ risk_weight: risk, diversity_weight: diversity })
      changeTopology('risk')
    } catch (e) {
      setError(failMessage(e))
    } finally {
      setBusy('')
    }
  }
  const plan = data?.plans[topology]
  const selected =
    topology === 'mesh'
      ? (plan?.theoretical_edges ?? [])
      : (data?.edges.filter((e) => plan?.edge_ids.includes(e.id)) ?? [])
  const failed = simulation?.failed_ids ?? []
  const bridges = simulation?.bridge_ids ?? plan?.metrics?.bridge_ids ?? []
  const cityName = (id: string) => data?.nodes.find((n) => n.id === id)?.name_mn ?? id
  const groups = [
    ...new Set(selected.map((e) => e.shared_risk_group).filter((s): s is string => !!s)),
  ].sort()
  const showCity = (n: City) => {
    setCity(n)
    setRoad(null)
    setTarget(n.id)
    setPath(null)
  }
  const showRoad = (e: Road) => {
    setRoad(e)
    setCity(null)
  }
  const runEvent = () => {
    const event: Event =
      eventKind === 'cut'
        ? { kind: 'cut', edge_ids: road ? [road.id] : [] }
        : eventKind === 'srlg'
          ? { kind: 'srlg', group: groups.includes(group) ? group : groups[0] }
          : { kind: eventKind, center, radius_km: radius, severity }
    void runSimulation(event)
  }
  const zone: Zone | null =
    page === 'lab' && (eventKind === 'flood' || eventKind === 'earthquake')
      ? {
          kind: eventKind,
          center,
          radius_km: radius,
          severity,
          effective_radius_km: radius * severity,
        }
      : (simulation?.zone ?? null)
  const exportJSON = () =>
    download(
      'steppelink-research.json',
      JSON.stringify(
        {
          project: 'SteppeLink Atlas',
          exported_at: new Date().toISOString(),
          dataset: data,
          selected_topology: topology,
          simulation,
          analyzed_route: path,
          assumptions: {
            speed_km_s: 200000,
            equipment_ms_hop_oneway: 0.2,
            hazard:
              'Regional circle versus road polyline, all intersecting links fail; no probability or real-time feed.',
            capex: 'Modeled terrain USD/km, not a quote',
            shared_data:
              'FiberGuard Mongolia road snapshot; OSM ODbL. Independent algorithms and UI.',
          },
        },
        null,
        2,
      ),
      'application/json',
    )
  const exportCSV = () => {
    if (!data) return
    const rows = [
      [
        'topology',
        'feasible',
        'distance_km',
        'capex_usd',
        'added_cost_pct',
        'bridges',
        'single_edge_survival_pct',
        'scenario_survival_pct',
        'max_modeled_rtt_ms',
      ],
      ...order.map((t) => {
        const p = data.plans[t],
          m = p.metrics
        return [
          t,
          p.feasible,
          m?.distance_km,
          m?.capex_usd,
          m?.added_cost_pct,
          m?.bridge_count,
          m?.single_survival_pct,
          m?.scenario_survival_pct,
          m?.max_rtt_ms,
        ]
      }),
    ]
    download(
      'steppelink-comparison.csv',
      '\uFEFF' +
        rows
          .map((row) => row.map((x) => `"${String(x ?? '').replaceAll('"', '""')}"`).join(','))
          .join('\r\n'),
      'text/csv;charset=utf-8',
    )
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <a
          className="wordmark"
          href="#atlas"
          onClick={(e) => {
            e.preventDefault()
            setPage('atlas')
          }}
        >
          <img src="/mark.svg" alt="" />
          <span>
            SteppeLink<small>NETWORK PLANNING ATLAS</small>
          </span>
        </a>
        <nav aria-label="Үндсэн цэс" className={mobile ? 'open' : ''}>
          {nav.map((n) => (
            <button
              key={n.id}
              className={page === n.id ? 'active' : ''}
              onClick={() => {
                setPage(n.id)
                setMobile(false)
              }}
            >
              <n.icon size={15} />
              {n.title}
            </button>
          ))}
        </nav>
        <div className="header-status">
          <span className="status-dot" /> Судалгааны орчин <span className="edition">MN / 01</span>
        </div>
        <button
          className="icon-btn mobile-toggle"
          aria-label="Цэс нээх"
          onClick={() => setMobile(!mobile)}
        >
          <Menu size={22} />
        </button>
      </header>
      {error && (
        <div className="error-banner" role="alert">
          <CircleAlert size={18} />
          <span>{error}</span>
          <button onClick={() => setError('')} aria-label="Алдаа хаах">
            <X size={18} />
          </button>
          {!data && <button onClick={() => void load()}>Дахин оролдох</button>}
        </div>
      )}
      {!data ? (
        <div className="initial-state">
          <Compass size={48} />
          <h1>Холболтын атлас</h1>
          <p>{busy || 'Backend ажиллаж буй эсэхийг шалгана уу: localhost:5102'}</p>
          {busy && <LoaderCircle className="spin" />}
        </div>
      ) : (
        <main>
          <div className="page-heading">
            <div>
              <div className="eyebrow">
                <span>МОНГОЛ УЛС</span>
                <i /> ДЭД БҮТЦИЙН СУДАЛГАА / {data.nodes.length} ЦЭГ
              </div>
              <h1>
                {page === 'atlas' ? (
                  <>
                    Замыг төлөвлө.<em>Холболтыг хамгаал.</em>
                  </>
                ) : page === 'compare' ? (
                  <>
                    Нэг газар нутаг.<em>Дөрвөн хувилбар.</em>
                  </>
                ) : page === 'lab' ? (
                  <>
                    Тасралтыг турш.<em>Бэлэн байдлыг хэмж.</em>
                  </>
                ) : page === 'inventory' ? (
                  <>
                    Сайн төлөвлөлт<em>өгөгдлөөс эхэлнэ.</em>
                  </>
                ) : (
                  <>
                    Тооцоонд тулгуурласан<em>судалгааны тэмдэглэл.</em>
                  </>
                )}
              </h1>
            </div>
            <div className="heading-note">
              <span className="number-label">
                {page === 'atlas'
                  ? '01 — ГАЗАРЗҮЙН ХАРАГДАЦ'
                  : page === 'compare'
                    ? '02 — ЭДИЙН ЗАСГИЙН СОНГОЛТ'
                    : page === 'lab'
                      ? '03 — ГЭМТЛИЙН ШИНЖИЛГЭЭ'
                      : page === 'inventory'
                        ? '04 — ЭХ ӨГӨГДӨЛ'
                        : '05 — СУДАЛГААНЫ ҮР ДҮН'}
              </span>
              <p>
                {page === 'atlas'
                  ? 'Авто замын бодит муруй дээр суурилсан шилэн кабелийн төлөвлөлтийн туршилтын атлас.'
                  : page === 'compare'
                    ? 'Хямд өртөг, давхардсан холбоос, эрсдэлийн зорилгын бодит ялгааг харьцуулна.'
                    : page === 'lab'
                      ? 'Нэг холбоосын тасралтаас бүсийн гамшиг хүртэл. Бүх үр дүн backend-ийн тооцоо.'
                      : page === 'inventory'
                        ? 'SQLite дээрх өөрийн өгөгдөл. Эх JSON snapshot өөрчлөгдөхгүй.'
                        : 'Тооцооны арга, гарал үүсэл, хязгаарлалт болон дахин шалгаж болох үр дүн.'}
              </p>
              <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">
                OSM road snapshot · тооцоолсон загвар <ExternalLink size={12} />
              </a>
            </div>
          </div>
          {(page === 'atlas' || page === 'lab') && (
            <>
              <div className="map-toolbar">
                <div className="topology-tabs" role="group" aria-label="Сүлжээний хувилбар">
                  {order.map((t) => (
                    <button
                      key={t}
                      className={topology === t ? 'selected' : ''}
                      onClick={() => changeTopology(t)}
                    >
                      <span style={{ background: colors[t] }} />
                      {titles[t]}
                    </button>
                  ))}
                </div>
                <button
                  className="text-btn"
                  onClick={resetSimulation}
                  disabled={!simulation && !path}
                >
                  <RotateCcw size={14} /> Тасралт цэвэрлэх
                </button>
              </div>
              {topology === 'mesh' && (
                <div className="notice">
                  <CircleAlert size={16} /> Full Mesh: шулуун зайгаар тооцсон онолын 231 холбоос.
                  Бодит авто зам, кабелийн corridor биш. Тасралтын симуляцид ашиглахгүй.
                </div>
              )}
              {plan && !plan.feasible && (
                <div className="notice danger">
                  Энэ candidate сүлжээнд шийдэл олдсонгүй: {plan.error}
                </div>
              )}
              <section
                className={`map-workspace ${page === 'lab' ? 'lab-workspace' : ''}`}
                aria-label="Газрын зураг ба шинжилгээ"
              >
                <aside className="planning-sheet">
                  {page === 'lab' ? (
                    <>
                      <div className="sheet-kicker">DISASTER LAB / СИМУЛЯЦИ</div>
                      <h2>Нөхцөл үүсгэх</h2>
                      <label>
                        Гэмтлийн төрөл
                        <select
                          value={eventKind}
                          onChange={(e) => setEventKind(e.target.value as Event['kind'])}
                        >
                          <option value="flood">Бүсийн үер</option>
                          <option value="earthquake">Газар хөдлөлт</option>
                          <option value="cut">Нэг кабель тасрах</option>
                          <option value="srlg">Хамтын corridor / SRLG</option>
                        </select>
                      </label>
                      {(eventKind === 'flood' || eventKind === 'earthquake') && (
                        <>
                          <label>
                            Голомт
                            <select
                              value={
                                data.nodes.find(
                                  (n) =>
                                    Math.abs(n.lat - center[0]) < 0.001 &&
                                    Math.abs(n.lon - center[1]) < 0.001,
                                )?.id ?? 'custom'
                              }
                              onChange={(e) => {
                                const n = data.nodes.find((x) => x.id === e.target.value)
                                if (n) setCenter([n.lat, n.lon])
                              }}
                            >
                              <option value="custom">Газрын зурагт байрлуулсан</option>
                              {data.nodes.map((n) => (
                                <option key={n.id} value={n.id}>
                                  {n.name_mn}
                                </option>
                              ))}
                            </select>
                          </label>
                          <div className="coordinate-value">
                            {center[0].toFixed(3)}° N / {center[1].toFixed(3)}° E
                          </div>
                          <label>
                            Суурь радиус <b>{radius} км</b>
                            <input
                              type="range"
                              min="10"
                              max="350"
                              step="5"
                              value={radius}
                              onChange={(e) => setRadius(+e.target.value)}
                            />
                          </label>
                          <label>
                            Хүчний үржүүлэгч <b>× {severity.toFixed(1)}</b>
                            <input
                              type="range"
                              min="0.5"
                              max="2"
                              step="0.1"
                              value={severity}
                              onChange={(e) => setSeverity(+e.target.value)}
                            />
                          </label>
                          <p className="fine-print">
                            Бодит радиус = {num(radius * severity)} км. Тойргийг огтолсон бүх зам
                            тасарна. Энэ нь физикийн гамшгийн прогноз биш.
                          </p>
                        </>
                      )}
                      {eventKind === 'cut' && (
                        <label>
                          Таслах холбоос
                          <select
                            value={road?.id ?? ''}
                            onChange={(e) =>
                              setRoad(selected.find((r) => r.id === e.target.value) ?? null)
                            }
                          >
                            <option value="">Холбоос сонгох</option>
                            {selected.map((e) => (
                              <option key={e.id} value={e.id}>
                                {cityName(e.source)} ↔ {cityName(e.target)}
                              </option>
                            ))}
                          </select>
                        </label>
                      )}
                      {eventKind === 'srlg' && (
                        <>
                          <label>
                            Shared Risk Link Group
                            <select
                              value={groups.includes(group) ? group : (groups[0] ?? '')}
                              onChange={(e) => setGroup(e.target.value)}
                            >
                              {groups.map((s) => (
                                <option key={s}>{s}</option>
                              ))}
                            </select>
                          </label>
                          <p className="fine-print">
                            Нэг SRLG-ийн бүх холбоос зэрэг тасарна. Logical 2-edge баталгаа үүнийг
                            хамрахгүй.
                          </p>
                        </>
                      )}
                      <button
                        className="btn primary full"
                        onClick={runEvent}
                        disabled={
                          !!busy ||
                          topology === 'mesh' ||
                          !plan?.feasible ||
                          (eventKind === 'cut' && !road)
                        }
                      >
                        <Radio size={16} /> Симуляци ажиллуулах
                      </button>
                      <button className="btn full" disabled={!simulation} onClick={resetSimulation}>
                        <RotateCcw size={15} /> Бүгдийг сэргээх
                      </button>
                      {simulation && (
                        <div
                          className={`simulation-status ${simulation.connected ? 'good' : 'bad'}`}
                        >
                          <span>
                            {simulation.connected ? 'ХОЛБОЛТ ХАДГАЛАГДСАН' : 'СҮЛЖЭЭ ХУВААГДСАН'}
                          </span>
                          <strong>
                            {num(simulation.availability_pct, 1)}%
                            <small>хот UB-тэй холбогдсон</small>
                          </strong>
                          <div>
                            {simulation.failed_ids.length} тасралт · {simulation.component_count}{' '}
                            компонент
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="sheet-kicker">ТӨЛӨВЛӨЛТИЙН ХУУДАС / 001</div>
                      <h2>
                        {topology === 'tree'
                          ? 'Хамгийн бага өртөг'
                          : topology === 'resilient'
                            ? 'Давхардсан холболт'
                            : topology === 'risk'
                              ? 'Эрсдэлийн жинлэлт'
                              : 'Онолын бүрэн сүлжээ'}
                      </h2>
                      <p className="sheet-intro">
                        {topology === 'tree'
                          ? 'Prim алгоритм бүх хотыг хамгийн бага CAPEX-аар холбоно. Нөөц замгүй.'
                          : topology === 'resilient'
                            ? 'MILP solver боломжит замуудаас хамгийн бага CAPEX-тай, bridge-гүй сүлжээ сонгоно.'
                            : topology === 'risk'
                              ? 'CAPEX, загварчилсан эрсдэл ба хамтын corridor-ийн торгуулийг нэг зорилгод жинлэнэ.'
                              : 'Хот бүр бусад бүх хоттой шууд холбогдох газарзүйн benchmark.'}
                      </p>
                      <div className="sheet-divider" />
                      {road ? (
                        <>
                          <div className="selection-label">
                            <Network size={14} /> ХОЛБООС / {road.id}
                          </div>
                          <h3>
                            {cityName(road.source)}
                            <span>↔</span>
                            {cityName(road.target)}
                          </h3>
                          <dl className="detail-list">
                            <div>
                              <dt>Авто замын урт</dt>
                              <dd>{num(road.distance_km, 1)} км</dd>
                            </div>
                            <div>
                              <dt>Загварын CAPEX</dt>
                              <dd>{money(road.cost_usd)}</dd>
                            </div>
                            <div>
                              <dt>Эрсдэлийн оноо</dt>
                              <dd>{road.risk_score.toFixed(2)} / 1</dd>
                            </div>
                            <div>
                              <dt>Corridor</dt>
                              <dd>{road.corridor_id}</dd>
                            </div>
                            <div>
                              <dt>SRLG</dt>
                              <dd>{road.shared_risk_group ?? '—'}</dd>
                            </div>
                            <div>
                              <dt>Bridge</dt>
                              <dd>{bridges.includes(road.id) ? 'Тийм / critical' : 'Үгүй'}</dd>
                            </div>
                            <div>
                              <dt>Эх сурвалж</dt>
                              <dd>{road.distance_source}</dd>
                            </div>
                          </dl>
                          {topology !== 'mesh' && (
                            <button
                              className={`btn full ${failed.includes(road.id) ? '' : 'danger-btn'}`}
                              disabled={!!busy}
                              onClick={() =>
                                void runSimulation(
                                  {
                                    kind: 'cut',
                                    edge_ids: failed.includes(road.id) ? [] : [road.id],
                                  },
                                  failed.filter((id) => id !== road.id),
                                )
                              }
                            >
                              {failed.includes(road.id) ? (
                                <RotateCcw size={15} />
                              ) : (
                                <Scissors size={15} />
                              )}
                              {failed.includes(road.id)
                                ? 'Энэ холбоосыг сэргээх'
                                : 'Кабель тасалж турших'}
                            </button>
                          )}
                        </>
                      ) : city ? (
                        <>
                          <div className="selection-label">
                            <Compass size={14} /> СҮЛЖЭЭНИЙ ЦЭГ
                          </div>
                          <h3>{city.name_mn}</h3>
                          <dl className="detail-list">
                            <div>
                              <dt>Аймаг / хот</dt>
                              <dd>{city.province}</dd>
                            </div>
                            <div>
                              <dt>Байршил</dt>
                              <dd>
                                {city.lat.toFixed(3)}, {city.lon.toFixed(3)}
                              </dd>
                            </div>
                            <div>
                              <dt>Загварын эрэлт</dt>
                              <dd>{num(city.traffic_demand_mbps)} Mbps</dd>
                            </div>
                            <div>
                              <dt>Төрөл</dt>
                              <dd>{city.node_type}</dd>
                            </div>
                          </dl>
                          <p className="fine-print">
                            Эрэлт нь судалгааны оролтын жин. Бодит урсгалын хэмжилт биш.
                          </p>
                        </>
                      ) : (
                        <div className="empty-selection">
                          <Compass size={27} />
                          <p>
                            Хот эсвэл зам сонгоод
                            <br />
                            дэлгэрэнгүйг харна уу.
                          </p>
                          <span>
                            {data.nodes.length} хот · {selected.length} холбоос
                          </span>
                        </div>
                      )}
                      {topology !== 'mesh' && (
                        <div className="route-tool">
                          <div className="sheet-divider" />
                          <div className="selection-label">A* / МАРШРУТ ХАЙХ</div>
                          <div className="route-selects">
                            <select
                              aria-label="Эхлэх хот"
                              value={source}
                              onChange={(e) => {
                                setSource(e.target.value)
                                setPath(null)
                              }}
                            >
                              {data.nodes.map((n) => (
                                <option key={n.id} value={n.id}>
                                  {n.name_mn}
                                </option>
                              ))}
                            </select>
                            <ArrowRight size={14} />
                            <select
                              aria-label="Очих хот"
                              value={target}
                              onChange={(e) => {
                                setTarget(e.target.value)
                                setPath(null)
                              }}
                            >
                              {data.nodes.map((n) => (
                                <option key={n.id} value={n.id}>
                                  {n.name_mn}
                                </option>
                              ))}
                            </select>
                          </div>
                          <button
                            className="btn full"
                            disabled={!!busy || !plan?.feasible}
                            onClick={() => void findRoute()}
                          >
                            Маршрут тооцоолох <ArrowRight size={15} />
                          </button>
                          {path && (
                            <div className="route-result">
                              {path.after.reachable ? (
                                <>
                                  <b>
                                    {num(path.after.distance_km, 1)} км{' '}
                                    <span>{num(path.after.modeled_rtt_ms, 2)} ms RTT</span>
                                  </b>
                                  <p>{path.after.nodes.map(cityName).join(' → ')}</p>
                                  <small>
                                    Нэг чиглэл: тархалт {num(path.after.propagation_one_way_ms, 2)}{' '}
                                    ms + төхөөрөмж {num(path.after.equipment_one_way_ms, 2)} ms
                                  </small>
                                  <small>
                                    Өмнөх зам: {num(path.before.distance_km, 1)} км /{' '}
                                    {num(path.before.modeled_rtt_ms, 2)} ms
                                  </small>
                                </>
                              ) : (
                                <p className="bad-text">Очих хотод хүрэх физик зам үлдээгүй.</p>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  )}
                </aside>
                <NetworkMap
                  nodes={data.nodes}
                  edges={selected}
                  topology={topology}
                  selected={road?.id}
                  failed={failed}
                  bridges={bridges}
                  backup={path?.after.edge_ids ?? []}
                  zone={zone}
                  onSelect={showRoad}
                  onCity={showCity}
                  focus={city ?? undefined}
                  onCenter={
                    page === 'lab' && (eventKind === 'flood' || eventKind === 'earthquake')
                      ? setCenter
                      : undefined
                  }
                />
              </section>
              {plan?.metrics && <MetricsRibbon plan={plan} simulation={simulation} />}
              {simulation && (
                <section className="simulation-results">
                  <div className="section-title">
                    <div>
                      <span className="eyebrow">FAILURE ANALYSIS</span>
                      <h2>Тасралтын дараах бодит тооцоо</h2>
                    </div>
                    <span className="tag">
                      {simulation.rerouted_count} хотын маршрут өөрчлөгдсөн
                    </span>
                  </div>
                  <div className="result-grid">
                    <article className="paper">
                      <div className="latency-comparison">
                        <small>UB → ХОТ / MAX RTT</small>
                        <strong>
                          {num(simulation.max_reference_rtt_before_ms, 2)} <ArrowRight size={14} />{' '}
                          {num(simulation.max_reference_rtt_after_ms, 2)} ms
                        </strong>
                        <span className={simulation.rtt_under_50 ? 'good-text' : 'bad-text'}>
                          {simulation.rtt_under_50
                            ? 'Хүртээмж бүрэн, загварын RTT < 50 ms'
                            : 'Холболт эсвэл 50 ms зорилго хангагдаагүй'}
                        </span>
                      </div>
                      <h3>Өртсөн хотууд</h3>
                      {simulation.affected_nodes.length ? (
                        <div className="chips">
                          {simulation.affected_nodes.map((id) => (
                            <button
                              key={id}
                              onClick={() => {
                                const n = data.nodes.find((c) => c.id === id)
                                if (n) showCity(n)
                              }}
                            >
                              {cityName(id)} <ChevronRight size={12} />
                            </button>
                          ))}
                        </div>
                      ) : (
                        <p className="good-text">
                          <Check size={16} /> Бүх хот Улаанбаатартай холбогдсон.
                        </p>
                      )}
                      <p className="fine-print">
                        Эрэлтийн жинтэй хүртээмж: {num(simulation.demand_availability_pct, 2)}%.
                        UB-ийн өөрийн эрэлтийг оруулаагүй.
                      </p>
                      <h3>Тасарсан холбоосууд</h3>
                      <div className="failed-list">
                        {failed.map((id) => {
                          const e = data.edges.find((x) => x.id === id)
                          return e ? (
                            <button key={id} onClick={() => showRoad(e)}>
                              <Scissors size={13} />
                              {cityName(e.source)} ↔ {cityName(e.target)}
                              <small>{id}</small>
                            </button>
                          ) : null
                        })}
                        {!failed.length && <p>Энэ нөхцөлд холбоос өртөөгүй.</p>}
                      </div>
                    </article>
                    <article className="paper">
                      <h3>Сэргээх санал</h3>
                      {simulation.recovery.proposals.length ? (
                        <>
                          <p>Компонентуудыг холбох Prim сонголт:</p>
                          {simulation.recovery.proposals.map((e) => (
                            <div className="recovery-row" key={e.id}>
                              <span>
                                {e.action === 'restore' ? 'Сэргээх' : 'Шинээр барих'}:{' '}
                                {cityName(e.source)} ↔ {cityName(e.target)}
                              </span>
                              <b>{money(e.cost_usd)}</b>
                            </div>
                          ))}
                          <div className="recovery-total">
                            Загварын нэмэлт CAPEX{' '}
                            <strong>{money(simulation.recovery.additional_capex_usd)}</strong>
                          </div>
                        </>
                      ) : (
                        <p>Сүлжээ холбоотой хэвээр. A* маршрутаар үлдсэн замыг ашиглана.</p>
                      )}
                      {!simulation.recovery.can_reconnect && (
                        <p className="bad-text">
                          Одоогийн candidate замуудаар бүрэн сэргээх боломжгүй.
                        </p>
                      )}
                      <p className="fine-print">
                        Энэ бол санал. Автоматаар шинэ кабель үүсгэхгүй. Засварын үнэ тодорхойгүй
                        тул бүтэн барилгын CAPEX-ийг орлуулсан үнэлгээ болгон ашиглав; идэвхтэй
                        гамшгийн бүсэд ажиллах боломжийг батлахгүй.
                      </p>
                    </article>
                  </div>
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>UB → Хот</th>
                          <th>Өмнө / км</th>
                          <th>Дараа / км</th>
                          <th>Өмнө / RTT</th>
                          <th>Дараа / RTT</th>
                          <th>Өөрчлөлт</th>
                        </tr>
                      </thead>
                      <tbody>
                        {simulation.routes.map((r) => (
                          <tr key={r.destination}>
                            <td>{cityName(r.destination)}</td>
                            <td>{num(r.before.distance_km, 1)}</td>
                            <td>{num(r.after.distance_km, 1)}</td>
                            <td>{num(r.before.modeled_rtt_ms, 2)} ms</td>
                            <td>{num(r.after.modeled_rtt_ms, 2)} ms</td>
                            <td>
                              {!r.after.reachable ? (
                                <span className="bad-text">Хүрэхгүй</span>
                              ) : r.rerouted ? (
                                <button
                                  className="text-btn"
                                  onClick={() => {
                                    setPath(r)
                                    setTarget(r.destination)
                                    setSource('ub')
                                  }}
                                >
                                  Нөөц зам харах <ArrowRight size={12} />
                                </button>
                              ) : (
                                'Хэвийн'
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              )}
              {page === 'atlas' && (
                <div className="atlas-footer-note">
                  <span>
                    <ShieldCheck size={18} /> Logical 2-edge ≠ газарзүйн гамшгийн хамгаалалт.
                  </span>
                  <button className="text-btn" onClick={() => setPage('lab')}>
                    Лабораторид турших <ArrowRight size={15} />
                  </button>
                </div>
              )}
            </>
          )}
          {page === 'compare' && (
            <>
              <section className="comparison-layout">
                <div className="paper optimization-controls">
                  <div className="sheet-kicker">OBJECTIVE / ЗОРИЛГЫН ФУНКЦ</div>
                  <h2>Юуг чухалчлах вэ?</h2>
                  <p>
                    Үндсэн CAPEX-ийн коэффициент 1. Нэмэлт эрсдэлийн жин болон SRLG хослолын
                    торгуулийг тохируулна.
                  </p>
                  <label>
                    Эрсдэлийн жин λ <b>{risk.toFixed(1)}</b>
                    <input
                      type="range"
                      min="0"
                      max="5"
                      step="0.1"
                      value={risk}
                      onChange={(e) => setRisk(+e.target.value)}
                    />
                  </label>
                  <label>
                    Corridor торгууль μ <b>{diversity.toFixed(1)}</b>
                    <input
                      type="range"
                      min="0"
                      max="2"
                      step="0.1"
                      value={diversity}
                      onChange={(e) => setDiversity(+e.target.value)}
                    />
                  </label>
                  <button
                    className="btn primary full"
                    disabled={!!busy}
                    onClick={() => void optimize()}
                  >
                    <SlidersHorizontal size={15} /> Дахин оновчлох
                  </button>
                  <div className="formula">
                    min Σ cₑ(1 + λrₑ)xₑ
                    <br />+ μ Σ min(cᵢ,cⱼ)yᵢⱼ
                    <br />
                    <small>
                      rₑ = 0.6 × risk + 0.4 × exposure
                      <br />
                      yᵢⱼ = xᵢ AND xⱼ; нэг SRLG дотор.
                    </small>
                  </div>
                  <p className="fine-print">
                    Жинг өөрчилсөн ч ижил сүлжээ гарч болно. Гамшгийн тэсвэр сайжирна гэсэн баталгаа
                    биш.
                  </p>
                </div>
                <article className="paper chart-paper">
                  <div className="section-title">
                    <div>
                      <span className="eyebrow">ЭДИЙН ЗАСГИЙН ХАРЬЦУУЛАЛТ</span>
                      <h2>Найдвартай холболтын үнэ</h2>
                    </div>
                    <span className="tag">USD / сая</span>
                  </div>
                  <div className="chart-box">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={order
                          .filter((t) => t !== 'mesh')
                          .map((t) => ({
                            name: titles[t].split(' / ')[1],
                            capex: (data.plans[t].metrics?.capex_usd ?? 0) / 1e6,
                            id: t,
                          }))}
                        margin={{ top: 10, right: 20, left: 0, bottom: 5 }}
                      >
                        <CartesianGrid vertical={false} stroke="#e6e2d9" />
                        <XAxis
                          dataKey="name"
                          axisLine={false}
                          tickLine={false}
                          tick={{ fontSize: 12 }}
                        />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                        <ChartTooltip
                          formatter={(v) => [`$${num(Number(v), 2)}M`, 'CAPEX']}
                          cursor={{ fill: '#f2f0e9' }}
                        />
                        <Bar dataKey="capex" maxBarSize={86} radius={[2, 2, 0, 0]}>
                          {order
                            .filter((t) => t !== 'mesh')
                            .map((t) => (
                              <Cell key={t} fill={colors[t]} />
                            ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="fine-print">
                    Онолын Full Mesh-ийн зардал тусдаа хүснэгтэд бий. CAPEX = замын км × таамагласан
                    terrain тариф. Барилгын үнийн санал биш.
                  </p>
                </article>
              </section>
              <div className="table-wrap comparison-table">
                <table>
                  <thead>
                    <tr>
                      <th>Үзүүлэлт</th>
                      {order.map((t) => (
                        <th key={t}>
                          <i style={{ background: colors[t] }} />
                          {titles[t]}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Нийт урт / км', (p: Plan) => num(p.metrics?.distance_km, 1)],
                      ['CAPEX / USD', (p: Plan) => (p.metrics ? money(p.metrics.capex_usd) : '—')],
                      [
                        'MST-ээс нэмэлт зардал',
                        (p: Plan) => `${num(p.metrics?.added_cost_pct, 2)}%`,
                      ],
                      ['Холбоосын тоо', (p: Plan) => num(p.metrics?.edge_count)],
                      ['Bridge / critical', (p: Plan) => num(p.metrics?.bridge_count)],
                      [
                        'Ганц тасралт даах хувь',
                        (p: Plan) => `${num(p.metrics?.single_survival_pct)}%`,
                      ],
                      [
                        'Scenario bank амьд үлдэх',
                        (p: Plan) =>
                          p.id === 'mesh'
                            ? 'Онолын; физик үнэлгээ биш'
                            : `${num(p.metrics?.scenario_survival_pct, 1)}% / ${num(p.metrics?.scenario_count)} нөхцөл`,
                      ],
                      [
                        'Хамгийн их загварын RTT',
                        (p: Plan) => `${num(p.metrics?.max_rtt_ms, 2)} ms`,
                      ],
                      [
                        'SRLG / corridor тоо',
                        (p: Plan) =>
                          p.id === 'mesh'
                            ? 'Бодит corridor үгүй'
                            : num(p.metrics?.corridor_diversity),
                      ],
                    ].map(([label, formatter]) => (
                      <tr key={String(label)}>
                        <td>{String(label)}</td>
                        {order.map((t) => (
                          <td key={t}>
                            {typeof formatter === 'function' ? formatter(data.plans[t]) : ''}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <section className="paper solver-paper">
                <div className="section-title">
                  <div>
                    <span className="eyebrow">SOLVER CERTIFICATE / БАТАЛГАА</span>
                    <h2>Шийдэл хэрхэн баталгаажсан бэ?</h2>
                  </div>
                  <span className="tag">CBC + cut generation</span>
                </div>
                <p>
                  Зэрэг ≥ 2 нөхцөлөөс эхлээд салангид компонент болон bridge үүсгэсэн огтлол бүрт
                  x(δ(S)) ≥ 2 хязгаарлалт нэмнэ. Бүх шатны optimum батлагдсан, эцсийн сүлжээ
                  холбоотой бөгөөд bridge-гүй үед өгөгдсөн candidate загварын зорилгыг глобал
                  хамгийн бага болгосон гэж үзнэ.
                </p>
                <div className="result-grid">
                  {(['resilient', 'risk'] as const).map((t) => {
                    const p = data.plans[t],
                      c = p.certificate
                    return (
                      <div key={t}>
                        <h3>{titles[t]}</h3>
                        {c ? (
                          <>
                            <div className="certificate-badges">
                              <span>
                                <ShieldCheck size={14} /> {c.status}
                              </span>
                              <span>
                                {c.rounds} шат / {c.cuts} cut
                              </span>
                              <span>
                                {c.verified_single_cuts
                                  ? 'Бүх single cut шалгасан'
                                  : 'Шалгалт дутуу'}
                              </span>
                            </div>
                            <table>
                              <thead>
                                <tr>
                                  <th>Шат</th>
                                  <th>Зорилго / M</th>
                                  <th>Компонент</th>
                                  <th>Bridge</th>
                                </tr>
                              </thead>
                              <tbody>
                                {c.trace.map((r) => (
                                  <tr key={r.round}>
                                    <td>{r.round}</td>
                                    <td>{num(r.objective_musd, 3)}</td>
                                    <td>{r.components}</td>
                                    <td>{r.bridges}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </>
                        ) : (
                          <p className="bad-text">{p.error}</p>
                        )}
                      </div>
                    )
                  })}
                </div>
                <p className="fine-print">
                  Risk зорилгын optimum нь цэвэр CAPEX-ийн optimum биш. Solver-ийн numerical
                  tolerance болон candidate өгөгдлийн хүрээнд хүчинтэй; бодит инженерийн маршрут
                  бүрэн оновчтой гэсэн үг биш.
                </p>
              </section>
            </>
          )}
          {page === 'inventory' && <Inventory data={data} reload={load} onError={setError} />}
          {page === 'reports' && (
            <>
              <section className="report-grid">
                <article className="paper">
                  <span className="eyebrow">RESEARCH EXPORT / 01</span>
                  <h2>Судалгаагаа авч гарах</h2>
                  <p>
                    Одоогийн дөрвөн сүлжээ, solver-ийн баталгаа, датасет, симуляци ба маршрут JSON-д
                    багтана. CSV нь дөрвөн topology-ийн харьцуулалт.
                  </p>
                  <div className="export-actions">
                    <button className="btn primary" onClick={exportJSON}>
                      <ArrowDownToLine size={16} /> JSON тайлан
                    </button>
                    <button className="btn" onClick={exportCSV}>
                      <ArrowDownToLine size={16} /> CSV харьцуулалт
                    </button>
                    <button className="btn" onClick={() => window.print()}>
                      Хэвлэх / PDF
                    </button>
                  </div>
                  <dl className="detail-list">
                    <div>
                      <dt>Датасет</dt>
                      <dd>
                        {data.nodes.length} хот / {data.edges.length} зам
                      </dd>
                    </div>
                    <div>
                      <dt>Өгөгдлийн revision</dt>
                      <dd>{data.revision}</dd>
                    </div>
                    <div>
                      <dt>Сонгосон сүлжээ</dt>
                      <dd>{titles[topology]}</dd>
                    </div>
                    <div>
                      <dt>Одоогийн тасралт</dt>
                      <dd>{failed.length}</dd>
                    </div>
                    <div>
                      <dt>Өгөгдлийн эх</dt>
                      <dd>OSM / OSRM snapshot</dd>
                    </div>
                  </dl>
                </article>
                <article className="paper report-assumptions">
                  <span className="eyebrow">MODEL NOTES / 02</span>
                  <h2>Юуг баталж болох вэ?</h2>
                  <ol>
                    <li>Prim нь candidate graph-ийн хамгийн бага CAPEX-тай spanning tree.</li>
                    <li>
                      MILP-ийн certificate нь зарласан зорилгын minimum-ийг candidate замуудын
                      хүрээнд батална.
                    </li>
                    <li>
                      2-edge гэдэг нь нэг logical холбоос тасрахад холболт хадгалагдахыг л хэлнэ.
                    </li>
                    <li>
                      OSRM зам нь авто замын маршрут. Асфальт, бодит кабель, эзэмшил, барих
                      зөвшөөрлийг батлахгүй.
                    </li>
                    <li>Эрсдэл, эрэлт, terrain тариф, SRLG нь судалгааны оролтын таамаг.</li>
                    <li>
                      Latency нь тархалт + нэг hop тутамд нэг чиглэлд 0.2 ms төхөөрөмжийн загвар.
                      Хэмжсэн ping биш.
                    </li>
                    <li>
                      Scenario bank: SRLG тус бүр болон dataset-ийн 0,4,8,… индексийн хотуудын 65 км
                      тойрог; өртсөн холбоостой нөхцөлүүд. Энэ хувь нь магадлал биш.
                    </li>
                    <li>
                      Хоёр hazard төрөл ижил circle-intersection engine ашиглана. Бодит үерийн
                      урсгал, магнитуд, цаг агаарын live API байхгүй.
                    </li>
                  </ol>
                </article>
              </section>
              <section className="paper">
                <span className="eyebrow">CALCULATION REFERENCE</span>
                <h2>Үндсэн томьёонууд</h2>
                <div className="formula-grid">
                  <div>
                    <b>CAPEX</b>
                    <p>Σ distanceₑ × terrain_rateₑ</p>
                    <small>Steppe $17,500 · Mountain $23,500 · Gobi $15,000 / км.</small>
                  </div>
                  <div>
                    <b>Загварын RTT</b>
                    <p>2 × (distance / 200 + hops × 0.2) ms</p>
                    <small>Оптик тархалтын хурд 200,000 км/с.</small>
                  </div>
                  <div>
                    <b>Зардлын нэмэгдэл</b>
                    <p>(CAPEX / MST_CAPEX − 1) × 100%</p>
                    <small>15–20% гэж урьдчилан батлахгүй.</small>
                  </div>
                </div>
                <p className="fine-print">
                  A* нь хамгийн богино урттай зам олно. Equipment delay-ийг дараа нь тусад нь нэмдэг
                  тул хамгийн бага latency-тай замыг тусад нь оновчлоогүй. Max RTT нь бүх хотын
                  хосын эдгээр маршрутын maximum.
                </p>
              </section>
            </>
          )}
        </main>
      )}
      <footer className="site-footer">
        <span>
          STEPPELINK ATLAS <i /> Монголын холболтын судалгаа
        </span>
        <span>
          Prim · Tarjan · MILP · A* <i /> Academic edition / 2026
        </span>
      </footer>
      <AnimatePresence>
        {busy && data && (
          <motion.div
            role="status"
            className="working-indicator"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 30, opacity: 0 }}
          >
            <LoaderCircle size={17} className="spin" />
            {busy}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
function MetricsRibbon({ plan, simulation }: { plan: Plan; simulation: Simulation | null }) {
  const m = plan.metrics!
  return (
    <div className="metrics-ribbon">
      <div>
        <small>НИЙТ КАБЕЛЬ</small>
        <strong>
          {num(m.distance_km, 1)}
          <span>км</span>
        </strong>
      </div>
      <div>
        <small>ТООЦООЛСОН CAPEX</small>
        <strong>{money(m.capex_usd)}</strong>
      </div>
      <div>
        <small>CRITICAL BRIDGES</small>
        <strong className={m.bridge_count ? 'bad-text' : ''}>
          {simulation?.bridge_ids.length ?? m.bridge_count}
          <span>холбоос</span>
        </strong>
      </div>
      <div>
        <small>ГАНЦ ТАСРАЛТ ДААХ</small>
        <strong>
          {num(m.single_survival_pct)}
          <span>% / baseline</span>
        </strong>
      </div>
      <div>
        <small>MAX ЗАГВАРЫН RTT</small>
        <strong>
          {num(m.max_rtt_ms, 2)}
          <span>ms</span>
        </strong>
      </div>
      <div>
        <small>ХОЛБОЛТЫН ТӨЛӨВ</small>
        <strong className="metric-status">
          {simulation
            ? `${num(simulation.availability_pct, 1)}%`
            : m.connected
              ? 'Холбоотой'
              : 'Тасарсан'}
          <span>
            {simulation ? `${simulation.component_count} компонент` : `${m.edge_count} зам`}
          </span>
        </strong>
      </div>
    </div>
  )
}
