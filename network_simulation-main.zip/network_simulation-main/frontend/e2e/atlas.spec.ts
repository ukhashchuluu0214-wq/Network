import { test, expect } from '@playwright/test'
async function ready(page: import('@playwright/test').Page) {
  await page.goto('/')
  await expect(page.getByRole('heading', { name: 'Давхардсан холболт' })).toBeVisible()
}
async function lab(page: import('@playwright/test').Page) {
  await page.getByRole('button', { name: 'Эрсдэлийн лаборатори', exact: true }).click()
  await page.getByLabel('Гэмтлийн төрөл').selectOption('cut')
}

test('atlas loads actual computed metrics with no runtime errors', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (e) => errors.push(e.message))
  await ready(page)
  await expect(page.locator('.metrics-ribbon')).toContainText('6,626.1')
  await expect(page.locator('.metrics-ribbon')).toContainText('$122.23M')
  await expect(page.locator('.leaflet-container')).toBeVisible()
  await expect(page.locator('.city-label')).toHaveCount(22)
  expect(errors).toEqual([])
})

test('Prim bridge cut disconnects, then reset restores', async ({ page }) => {
  await ready(page)
  await lab(page)
  await page.getByRole('button', { name: '01 / Prim MST', exact: true }).click()
  await page.getByLabel('Таслах холбоос').selectOption('sl-029')
  await page.getByRole('button', { name: 'Симуляци ажиллуулах', exact: true }).click()
  await expect(page.locator('.simulation-status')).toContainText('77.3%')
  await expect(page.locator('.simulation-status')).toContainText('2 компонент')
  await expect(page.locator('.chips')).toContainText('Дархан')
  await page.getByRole('button', { name: 'Бүгдийг сэргээх', exact: true }).click()
  await expect(page.locator('.simulation-status')).toHaveCount(0)
})

test('MILP single cut stays connected with surviving backup route', async ({ page }) => {
  await ready(page)
  await lab(page)
  await page.getByLabel('Таслах холбоос').selectOption('sl-028')
  await page.getByRole('button', { name: 'Симуляци ажиллуулах', exact: true }).click()
  await expect(page.locator('.simulation-status')).toContainText('ХОЛБОЛТ ХАДГАЛАГДСАН')
  await expect(page.locator('.simulation-status')).toContainText('100%')
  await expect(page.locator('.backup-line').first()).toBeVisible()
  await expect(page.locator('.simulation-results')).toContainText('Сэргээх санал')
})

test('flood and SRLG simultaneous failures are computed', async ({ page }) => {
  await ready(page)
  await page.getByRole('button', { name: 'Эрсдэлийн лаборатори', exact: true }).click()
  await page.getByRole('button', { name: 'Симуляци ажиллуулах', exact: true }).click()
  await expect(page.locator('.failed-list button').first()).toBeVisible()
  expect(await page.locator('.failed-list button').count()).toBeGreaterThan(1)
  await expect(page.locator('.simulation-status')).toContainText('СҮЛЖЭЭ ХУВААГДСАН')
  await page.getByRole('button', { name: 'Бүгдийг сэргээх', exact: true }).click()
  await page.getByLabel('Гэмтлийн төрөл').selectOption('srlg')
  await page.getByLabel('Shared Risk Link Group').selectOption('western-pass')
  await page.getByRole('button', { name: 'Симуляци ажиллуулах', exact: true }).click()
  await expect(page.locator('.failed-list button').first()).toBeVisible()
  expect(await page.locator('.failed-list button').count()).toBeGreaterThan(1)
})

test('A* route analysis and theoretical mesh restriction', async ({ page }) => {
  await ready(page)
  await page.getByRole('button', { name: 'Маршрут тооцоолох', exact: true }).click()
  await expect(page.locator('.route-result')).toContainText('420.9 км')
  await expect(page.locator('.route-result')).toContainText('5.01 ms')
  await page.getByRole('button', { name: '04 / Full Mesh', exact: true }).click()
  await expect(page.locator('.notice')).toContainText('онолын 231 холбоос')
  await expect(page.locator('.metrics-ribbon')).toContainText('231 зам')
})

test('comparison solves custom objective with certificate', async ({ page }) => {
  await ready(page)
  await page.getByRole('button', { name: 'Хувилбарууд', exact: true }).click()
  await expect(page.locator('.comparison-table')).toContainText('37.32%')
  await page.getByLabel('Эрсдэлийн жин λ').fill('2')
  await page.getByRole('button', { name: 'Дахин оновчлох', exact: true }).click()
  await expect(page.locator('.working-indicator')).toHaveCount(0)
  await expect(page.locator('.certificate-badges').first()).toContainText('optimal')
  await expect(page.locator('.recharts-surface').first()).toBeVisible()
})

test('inventory search and persisted edit restore original value', async ({ page }) => {
  await ready(page)
  await page.getByRole('button', { name: 'Өгөгдлийн сан', exact: true }).click()
  await page.getByLabel('Өгөгдөл хайх').fill('sl-001')
  await expect(page.locator('tbody tr')).toHaveCount(1)
  await page.getByRole('button', { name: 'sl-001 засах', exact: true }).click()
  const initial = await page.getByLabel('Risk score', { exact: true }).inputValue()
  await page.getByLabel('Risk score', { exact: true }).fill('.53')
  await page.getByRole('button', { name: 'Хадгалах', exact: true }).click()
  await expect(page.getByRole('dialog')).toHaveCount(0)
  await expect(page.locator('tbody tr')).toContainText('0.53')
  await page.getByRole('button', { name: 'sl-001 засах', exact: true }).click()
  await page.getByLabel('Risk score', { exact: true }).fill(initial)
  await page.getByRole('button', { name: 'Хадгалах', exact: true }).click()
  await expect(page.getByRole('dialog')).toHaveCount(0)
})

test('JSON and CSV reports download real algorithm results', async ({ page }) => {
  await ready(page)
  await page.getByRole('button', { name: 'Судалгааны тайлан', exact: true }).click()
  const jsonEvent = page.waitForEvent('download')
  await page.getByRole('button', { name: 'JSON тайлан', exact: true }).click()
  const json = await jsonEvent
  expect(json.suggestedFilename()).toBe('steppelink-research.json')
  const stream = await json.createReadStream()
  let text = ''
  for await (const chunk of stream!) text += chunk.toString()
  const result = JSON.parse(text)
  expect(result.dataset.plans.resilient.certificate.global_optimum).toBe(true)
  expect(result.dataset.plans.resilient.metrics.edge_count).toBe(22)
  const csvEvent = page.waitForEvent('download')
  await page.getByRole('button', { name: 'CSV харьцуулалт', exact: true }).click()
  expect((await csvEvent).suggestedFilename()).toBe('steppelink-comparison.csv')
})

test('mobile menu, responsive map and route controls', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await ready(page)
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
  await page.getByRole('button', { name: 'Цэс нээх', exact: true }).click()
  await page.getByRole('button', { name: 'Эрсдэлийн лаборатори', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Нөхцөл үүсгэх' })).toBeVisible()
  await page.screenshot({ path: 'test-results/mobile-atlas.png', fullPage: true })
})
