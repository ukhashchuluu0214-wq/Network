import json
from unittest.mock import patch
import pytest
from backend.atlas.store import Store
from backend.atlas.planner import PlanningError


def test_health(client):
    result=client.get('/api/health')
    assert result.status_code==200
    assert result.json['project']=='SteppeLink Atlas'


def test_bootstrap_certificate(client):
    result=client.get('/api/bootstrap')
    assert result.status_code==200
    data=result.json
    assert len(data['nodes'])==22
    assert data['plans']['resilient']['certificate']['global_optimum']
    assert data['plans']['resilient']['metrics']['added_cost_pct']==37.32
    assert data['plans']['mesh']['metrics']['edge_count']==231


def test_route_endpoint_and_validation(client):
    assert client.post('/api/route',json={'target':'darkhan'}).json['after']['reachable']
    assert client.post('/api/route',json={'target':'missing'}).status_code==422
    assert client.post('/api/route',json={'target':'ub','failed_ids':['invalid']}).status_code==422


def test_no_simulating_theory(client):
    result=client.post('/api/failures',json={'topology':'mesh','event':{'kind':'cut','edge_ids':[]}})
    assert result.status_code==422


def test_nodes_create_edit_delete(client):
    node={'id':'testcity','name_mn':'Тест','name_en':'Test','province':'Тест','lat':47,'lon':104,'traffic_demand_mbps':800}
    assert client.post('/api/inventory/nodes',json=node).status_code==201
    assert client.post('/api/inventory/nodes',json=node).status_code==422
    node['traffic_demand_mbps']=900
    assert client.put('/api/inventory/nodes/testcity',json=node).json['item']['traffic_demand_mbps']==900
    assert client.delete('/api/inventory/nodes/testcity').status_code==200
    assert client.delete('/api/inventory/nodes/testcity').status_code==422


def test_connected_city_protected(client):
    node=client.get('/api/inventory/nodes').json['items'][0]
    node['lat']+=.1
    assert client.put('/api/inventory/nodes/'+node['id'],json=node).status_code==422
    assert client.delete('/api/inventory/nodes/ub').status_code==422
    assert client.delete('/api/inventory/nodes/darkhan').status_code==422


def test_route_modify_recalculates_capex(client):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['distance_km']=300
    edge['cost_usd']=1
    edge['distance_source']='user_estimate'
    result=client.put('/api/inventory/routes/'+edge['id'],json=edge)
    assert result.status_code==200
    assert result.json['item']['cost_usd']==300*23500
    assert result.json['item']['latency_ms']==1.5


def test_route_create_duplicate_reject_delete(client):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['id']='sl-test'
    assert client.post('/api/inventory/routes',json=edge).status_code==422
    edge['source'],edge['target']=edge['target'],edge['source']
    assert client.post('/api/inventory/routes',json=edge).status_code==422
    assert client.delete('/api/inventory/routes/sl-001').status_code==200
    edge['distance_source']='user_estimate'
    assert client.post('/api/inventory/routes',json=edge).status_code==201


def test_validated_length_requires_evidence(client):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['distance_source']='validated_route'
    assert client.put('/api/inventory/routes/'+edge['id'],json=edge).status_code==422
    edge['validation_note']='Academic fixture survey reference, not a real survey.'
    assert client.put('/api/inventory/routes/'+edge['id'],json=edge).status_code==200


@pytest.mark.parametrize('bad',[float('inf'),float('nan'),-10,True,'bad'])
def test_numeric_validation(client,bad):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['risk_score']=bad
    assert client.put('/api/inventory/routes/'+edge['id'],json=edge).status_code==422


def test_reset_requires_confirmation(client):
    assert client.post('/api/reset',json={}).status_code==422
    assert client.delete('/api/inventory/routes/sl-001').status_code==200
    assert client.post('/api/reset',json={'confirm':'RESET_ATLAS'}).status_code==200
    assert len(client.get('/api/inventory/routes').json['items'])==45


def test_structured_errors(client):
    assert client.get('/api/does-not-exist').json['error']['code']=='Not Found'
    assert client.post('/api/plan',json=[]).status_code==422
    assert client.get('/api/inventory/invalid').status_code==422


def test_road_preview_mocked_cache(client):
    with patch('backend.app.fetch_road',return_value={'distance_km':200,'geometry':[[47,100],[48,101]],'routing':{'cache_hit':True}}) as fetch:
        result=client.post('/api/road-preview',json={'source':'ub','target':'darkhan'})
        assert result.status_code==200 and result.json['routing']['cache_hit']
        fetch.assert_called_once()
    assert client.post('/api/road-preview',json={'source':'ub','target':'ub'}).status_code==422


def test_osm_provenance_cannot_be_fabricated(client):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['distance_km']+=1
    result=client.put('/api/inventory/routes/'+edge['id'],json=edge)
    assert result.status_code==422 and 'provenance' in result.json['error']['message']


def test_malformed_geometry_not_silently_dropped(client):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['geometry'].insert(1,['invalid'])
    assert client.put('/api/inventory/routes/'+edge['id'],json=edge).status_code==422


def test_geometry_must_reach_endpoints(client):
    edge=client.get('/api/inventory/routes').json['items'][0]
    edge['geometry']=[[45,100],[46,101]]
    assert client.put('/api/inventory/routes/'+edge['id'],json=edge).status_code==422


def test_simulation_event_must_be_object(client):
    assert client.post('/api/failures',json={'event':[]}).status_code==422


def test_fresh_osrm_cache_accepts_semicolon_coordinate_url(dataset,tmp_path):
    import copy
    import hashlib
    seed=tmp_path/'seed.json'
    seed.write_text(json.dumps(dataset))
    store=Store(tmp_path/'test.sqlite3',seed)
    edge=copy.deepcopy(dataset['edges'][0])
    edge['distance_km']+=.1
    coords={n['id']:n for n in dataset['nodes']}
    a,b=coords[edge['source']],coords[edge['target']]
    url='https://example.test/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full'%(a['lon'],a['lat'],b['lon'],b['lat'])
    edge['routing']={'request_url':url}
    cache=tmp_path/'road-cache'
    cache.mkdir()
    (cache/(hashlib.sha256(url.encode()).hexdigest()+'.json')).write_text(json.dumps(edge))
    result=store.save_route(edge,True)
    assert result['distance_source']=='osm_road_route'
    assert result['distance_km']==edge['distance_km']
