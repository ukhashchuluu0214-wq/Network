import copy
import json
from pathlib import Path
import pytest
from backend.app import create_app
from backend.atlas.planner import prim_tree, survivable_plan

ROOT = Path(__file__).resolve().parents[1]

@pytest.fixture(scope='session')
def dataset():
    return json.loads((ROOT / 'data/mongolia-roads.json').read_text())

@pytest.fixture(scope='session')
def tree(dataset):
    return prim_tree(dataset['nodes'], dataset['edges'])

@pytest.fixture(scope='session')
def resilient(dataset):
    return survivable_plan(dataset['nodes'], dataset['edges'])

@pytest.fixture
def client(tmp_path):
    app = create_app(tmp_path / 'test.sqlite3')
    app.config['TESTING'] = True
    return app.test_client()

@pytest.fixture
def small():
    nodes = [{'id': str(i), 'lat': 45+i*.05, 'lon': 100+i*.03, 'traffic_demand_mbps': 100} for i in range(4)]
    edges = []
    from itertools import combinations
    for i,(a,b) in enumerate(combinations(nodes,2)):
        edges.append({'id': 'e%s'%i, 'source': a['id'], 'target': b['id'], 'distance_km': 20+i, 'cost_usd': [10,17,24,11,18,12][i], 'risk_score': .2, 'disaster_exposure': .3, 'corridor_id': 'c%s'%i, 'shared_risk_group': 's' if i < 2 else None, 'geometry': [[a['lat'],a['lon']],[b['lat'],b['lon']]]})
    return copy.deepcopy(nodes), copy.deepcopy(edges)
