import copy
import pytest
from backend.atlas.planner import PlanningError, graph, route
from backend.atlas.simulation import disaster_ids, simulate
from backend.atlas.geography import intersects_circle


def test_mst_cut_example(dataset,tree):
    result=simulate(dataset['nodes'],dataset['edges'],tree,{'kind':'cut','edge_ids':['sl-029']})
    assert result['component_count']==2
    assert set(result['affected_nodes'])=={'darkhan','erdenet','bulgan','murun','sukhbaatar'}
    assert result['availability_pct']==77.27
    assert result['recovery']['proposals']


def test_exact_network_survives_cut(dataset,resilient):
    edges,_=resilient
    result=simulate(dataset['nodes'],dataset['edges'],edges,{'kind':'cut','edge_ids':[edges[0]['id']]})
    assert result['connected'] and not result['affected_nodes']
    assert result['demand_availability_pct']==100


def test_disaster_exact_geometry_selection(dataset,resilient):
    edges,_=resilient
    event={'kind':'flood','center':[47.918,106.917],'radius_km':80,'severity':1.2}
    ids,zone=disaster_ids(edges,event)
    expected={e['id'] for e in edges if intersects_circle(e['geometry'],event['center'],96)}
    assert set(ids)==expected
    assert zone['effective_radius_km']==96
    assert len(ids)>1


def test_srlg_all_and_only_members(dataset,resilient):
    edges,_=resilient
    group=edges[0]['shared_risk_group']
    ids,zone=disaster_ids(edges,{'kind':'srlg','group':group})
    assert set(ids)=={e['id'] for e in edges if e['shared_risk_group']==group}
    assert zone is None


def test_simulation_no_mutation(dataset,resilient):
    edges,_=resilient
    saved=copy.deepcopy((dataset,edges))
    simulate(dataset['nodes'],dataset['edges'],edges,{'kind':'cut','edge_ids':[edges[0]['id']]})
    assert (dataset,edges)==saved


def test_rerouting_surviving_only(dataset,resilient):
    edges,_=resilient
    result=simulate(dataset['nodes'],dataset['edges'],edges,{'kind':'cut','edge_ids':[edges[0]['id']]})
    assert result['rerouted_count']>0
    for r in result['routes']:
        assert not (set(r['after']['edge_ids']) & set(result['failed_ids']))
        assert set(r['after']['edge_ids']) <= {e['id'] for e in edges}


def test_multiple_cuts_cumulative_and_restore(dataset,resilient):
    edges,_=resilient
    a,b=edges[0]['id'],edges[1]['id']
    result=simulate(dataset['nodes'],dataset['edges'],edges,{'kind':'cut','edge_ids':[b]},[a])
    assert result['failed_ids']==sorted([a,b])
    restored=simulate(dataset['nodes'],dataset['edges'],edges,{'kind':'cut','edge_ids':[]},[b])
    assert restored['failed_ids']==[b]


def test_recovery_never_applied_implicitly(dataset,tree):
    result=simulate(dataset['nodes'],dataset['edges'],tree,{'kind':'cut','edge_ids':['sl-029']})
    assert result['component_count']==2
    assert any(not r['after']['reachable'] for r in result['routes'])
    assert result['recovery']['additional_capex_usd']==sum(p['cost_usd'] for p in result['recovery']['proposals'])


@pytest.mark.parametrize('event',[{'kind':'cut','edge_ids':['bad']},{'kind':'volcano'},{'kind':'srlg','group':'bad'},{'kind':'flood','center':[47,100],'radius_km':-1},{'kind':'earthquake','center':[47,100],'severity':10}])
def test_invalid_events(small,event):
    with pytest.raises(PlanningError):disaster_ids(small[1],event)


def test_single_cut_can_exceed_latency_target(dataset,resilient):
    edges,_=resilient
    result=simulate(dataset['nodes'],dataset['edges'],edges,{'kind':'cut','edge_ids':['sl-028']})
    assert result['connected']
    assert result['max_reference_rtt_after_ms']>50
    assert not result['rtt_under_50']
