import itertools
import math
import random
import networkx as nx
import pytest
from backend.atlas.planner import PlanningError, graph, prim_tree, tarjan_bridges, survivable_plan, theoretical_mesh, metrics, route
from backend.atlas.geography import haversine, intersects_circle


def test_seed_integrity(dataset):
    assert len(dataset['nodes']) == 22
    assert len(dataset['edges']) == 45
    assert len({e['id'] for e in dataset['edges']}) == 45
    assert len({tuple(sorted((e['source'],e['target']))) for e in dataset['edges']}) == 45
    assert all(len(e['geometry']) > 2 and e['distance_source'] == 'osm_road_route' for e in dataset['edges'])
    assert dataset['metadata']['verified_routes'] is False


def test_tree_is_21_connected(dataset, tree):
    g = graph(dataset['nodes'],tree)
    assert len(tree) == 21
    assert nx.is_connected(g)
    assert len(tarjan_bridges(g)) == 21


def test_prim_weight_equals_kruskal(dataset, tree):
    reference = nx.minimum_spanning_tree(graph(dataset['nodes'],dataset['edges']),algorithm='kruskal',weight='cost_usd')
    assert sum(e['cost_usd'] for e in tree) == sum(d['cost_usd'] for _,_,d in reference.edges(data=True))


def test_resilient_certificate(dataset, resilient):
    edges, certificate = resilient
    assert certificate['status'] == 'optimal'
    assert certificate['global_optimum']
    assert certificate['verified_single_cuts']
    assert certificate['rounds'] >= 1
    assert nx.is_connected(graph(dataset['nodes'],edges))
    assert not tarjan_bridges(graph(dataset['nodes'],edges))


@pytest.mark.parametrize('edge_index', range(22))
def test_every_single_edge_survives(dataset, resilient, edge_index):
    edges,_ = resilient
    assert nx.is_connected(graph(dataset['nodes'],edges,[edges[edge_index]['id']]))


def test_bridge_cut_disconnects(dataset,tree):
    assert not nx.is_connected(graph(dataset['nodes'],tree,[tree[0]['id']]))


def test_infeasible_tree_rejected(dataset,tree):
    with pytest.raises(PlanningError,match='cannot support'):
        survivable_plan(dataset['nodes'],tree)


def test_disconnected_mst_rejected(small):
    nodes,edges = small
    with pytest.raises(PlanningError,match='disconnected'):
        prim_tree(nodes,edges[:1])


def test_exact_matches_exhaustive_search(small):
    nodes,edges = small
    feasible = []
    for mask in range(1<<len(edges)):
        selected = [e for i,e in enumerate(edges) if mask & (1<<i)]
        g = graph(nodes,selected)
        if nx.is_connected(g) and not list(nx.bridges(g)):
            feasible.append(sum(e['cost_usd'] for e in selected))
    selected,certificate = survivable_plan(nodes,edges)
    assert sum(e['cost_usd'] for e in selected) == min(feasible)
    assert certificate['global_optimum']


def test_risk_and_pair_objective_matches_exhaustive(small):
    nodes,edges=small
    risk,diversity=1.7,.6
    def objective(selected):
        base=sum(e['cost_usd']*(1+risk*(.6*e['risk_score']+.4*e['disaster_exposure'])) for e in selected)
        pairs=sum(diversity*min(a['cost_usd'],b['cost_usd']) for a,b in itertools.combinations(selected,2) if a['shared_risk_group'] and a['shared_risk_group']==b['shared_risk_group'])
        return base+pairs
    values=[]
    for mask in range(1<<len(edges)):
        selected=[e for i,e in enumerate(edges) if mask & (1<<i)]
        g=graph(nodes,selected)
        if nx.is_connected(g) and not list(nx.bridges(g)):
            values.append(objective(selected))
    selected,_=survivable_plan(nodes,edges,risk,diversity)
    assert objective(selected) == pytest.approx(min(values))


@pytest.mark.parametrize('seed',range(5))
def test_tarjan_matches_networkx(seed):
    g=nx.gnp_random_graph(16,.13,seed=seed)
    for i,(u,v) in enumerate(g.edges):g[u][v]['id']='edge%s'%i
    expected=sorted(g[u][v]['id'] for u,v in nx.bridges(g))
    assert tarjan_bridges(g)==expected


@pytest.mark.parametrize('target',['olgii','darkhan','khovd','sainshand','choibalsan'])
def test_astar_matches_dijkstra(dataset,resilient,target):
    edges,_=resilient
    p=route(dataset['nodes'],edges,'ub',target)
    expected=nx.shortest_path_length(graph(dataset['nodes'],edges),'ub',target,weight='distance_km')
    assert p['distance_km']==pytest.approx(expected,abs=.00051)
    assert p['modeled_rtt_ms']==pytest.approx(2*(expected/200+len(p['edge_ids'])*.2),abs=.00001)


def test_geodesic_known_units():
    assert haversine([0,0],[0,1])==pytest.approx(111.195,abs=.001)
    assert haversine([47,100],[47,100])==0


def test_circle_uses_segments_not_just_endpoints():
    assert intersects_circle([[47,99],[47,101]],[47,100],1)
    assert not intersects_circle([[47,99],[47,101]],[48,100],1)


def test_mesh_only_theory(dataset):
    edges=theoretical_mesh(dataset['nodes'])
    assert len(edges)==231
    assert all(e['status']=='theoretical' for e in edges)
    assert not tarjan_bridges(graph(dataset['nodes'],edges))
    assert metrics(dataset['nodes'],edges)['scenario_survival_pct'] is None


def test_metrics_and_capex_consistent(dataset,tree,resilient):
    assert metrics(dataset['nodes'],tree)['distance_km']==pytest.approx(4753.698)
    assert sum(e['cost_usd'] for e in tree)==89015325
    for e in dataset['edges']:
        rate={'steppe':17500,'mountain':23500,'gobi':15000}[e['terrain']]
        assert e['cost_usd']==pytest.approx(e['distance_km']*rate)
    edges,_=resilient
    m=metrics(dataset['nodes'],edges)
    assert m['bridge_count']==0 and m['single_survival_pct']==100
    assert m['distance_km']==pytest.approx(6626.102)
    assert m['capex_usd']==122234284


def test_same_node_zero_latency(dataset,tree):
    p=route(dataset['nodes'],tree,'ub','ub')
    assert p['modeled_rtt_ms']==0 and p['edge_ids']==[]


def test_unreachable_no_fake_path(small):
    nodes,edges=small
    p=route(nodes,edges[:1],'0','3')
    assert not p['reachable'] and p['distance_km'] is None
