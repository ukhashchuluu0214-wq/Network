"""Create a source-only handoff archive without local state/dependencies/secrets."""
import os
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def main():
    root = Path(__file__).resolve().parents[1]
    target = root.parent / 'steppelink-atlas.zip'
    excluded = {'.venv', 'node_modules', 'dist', '__pycache__', '.pytest_cache', 'test-results', 'playwright-report', '.git', 'road-cache'}
    with ZipFile(target, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for directory, folders, names in os.walk(root):
            folders[:] = sorted(f for f in folders if f not in excluded)
            for name in sorted(names):
                if name in {'.env', '.DS_Store'} or name.endswith(('.pyc', '.sqlite3', '.sqlite3-wal', '.sqlite3-shm')):
                    continue
                path = Path(directory) / name
                archive.write(path, str(Path(root.name) / path.relative_to(root)))
    print('%s (%s bytes)' % (target, target.stat().st_size))


if __name__ == '__main__':
    main()
