"""Reproduce independent plan metrics, certificates and one common-edge cut."""
import json
from pathlib import Path
from backend.atlas.planner import prim_tree, survivable_plan, theoretical_mesh, metrics
from backend.atlas.simulation import simulate


def main():
    data = json.loads((Path(__file__).resolve().parents[1] / 'data/mongolia-roads.json').read_text())
    nodes, edges = data['nodes'], data['edges']
    tree = prim_tree(nodes, edges)
    resilient, cert = survivable_plan(nodes, edges)
    risk, risk_cert = survivable_plan(nodes, edges, 1.5, .4)
    base = sum(e['cost_usd'] for e in tree)
    result = {'plans': {}, 'certificates': {'resilient': cert, 'risk': risk_cert}, 'cuts': {}}
    for name, selected in [('tree', tree), ('resilient', resilient), ('risk', risk), ('mesh', theoretical_mesh(nodes))]:
        m = metrics(nodes, selected)
        m['added_cost_pct'] = round((m['capex_usd'] / base - 1) * 100, 2)
        result['plans'][name] = m
    for name, selected in [('tree', tree), ('resilient', resilient)]:
        result['cuts'][name] = simulate(nodes, edges, selected, {'kind': 'cut', 'edge_ids': ['sl-028']})
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
