import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { createServer } from 'node:net'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
const root = fileURLToPath(new URL('..', import.meta.url))
const python = path.join(root, '.venv/bin/python')
if (!existsSync(python) || !existsSync(path.join(root, 'frontend/node_modules/vite/bin/vite.js'))) {
  console.error('Эхлээд README.md-ийн installation командыг ажиллуулна уу. .venv болон frontend/node_modules хэрэгтэй.')
  process.exit(1)
}
const port = Number(process.env.ATLAS_PORT || 5102)
for (const p of [port, 5180]) {
  try {
    await new Promise((resolve, reject) => {
      const server = createServer()
      server.once('error', reject)
      server.listen(p, '127.0.0.1', () => server.close(resolve))
    })
  } catch {
    console.error(`Порт ${p} ашиглагдаж байна. Тухайн Atlas процессыг зогсоогоод дахин ажиллуулна уу.`)
    process.exit(1)
  }
}
if (port !== 5102) console.warn('ATLAS_PORT өөрчилсөн бол frontend/vite.config.ts дэх proxy-г мөн тааруулна уу.')
const backend = spawn(python, ['-m', 'backend.app'], { cwd: root, stdio: 'inherit' })
const frontend = spawn(process.execPath, ['node_modules/vite/bin/vite.js'], { cwd: path.join(root, 'frontend'), stdio: 'inherit' })
let stopping = false
function stop(code = 0) {
  if (stopping) return
  stopping = true
  backend.kill('SIGTERM'); frontend.kill('SIGTERM')
  setTimeout(() => process.exit(code), 250)
}
for (const child of [backend, frontend]) {
  child.on('error', e => { console.error(e.message); stop(1) })
  child.on('exit', code => { if (!stopping) stop(code || 0) })
}
process.on('SIGINT', () => stop()); process.on('SIGTERM', () => stop())
console.log('\nSteppeLink Atlas → http://127.0.0.1:5180\nBackend → http://127.0.0.1:5102/api/health\nCtrl+C: хоёуланг зогсооно.\n')
