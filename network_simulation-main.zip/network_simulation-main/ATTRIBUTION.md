# Өгөгдлийн гарал ба дахин ашиглалт

SteppeLink Atlas нь өөр UI, algorithm implementation, API, persistence-тэй шинэ local төсөл. Шинэ төслийг бие даан цуглуулсан бүхэл өгөгдөлтэй гэж танилцуулахгүй.

- `data/mongolia-roads.json` нь FiberGuard Mongolia төслийн `data/network.roads.json` snapshot-оос уламжлагдсан. Энэ snapshot-ийг анх OSRM-ийн OSM driving response-уудаар 2026-10-18-нд үүсгэсэн. Хотын координат/нэр болон 45 candidate pair, terrain, demand, risk, SRLG оролтуудыг хамт ашигласан. Шинэ snapshot metadata-д derived_from, original_id талбар хадгалсан.
- Авто замын geographic мэдээлэл: **© OpenStreetMap contributors**, [OpenStreetMap copyright](https://www.openstreetmap.org/copyright), [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/). Data-derived distributions-д ODbL-ийн attribution/share-alike шаардлагыг дагана.
- Routing service: [FOSSGIS OSRM](https://routing.openstreetmap.de/), [OSRM API reference](https://project-osrm.org/docs/v5.24.0/api/). Энэ routing service дээр FiberGuard/Atlas-ийн survey хийсэн бодит fiber corridor байрладаг гэсэн үг биш.
- `frontend/public/mongolia.geojson` нь FiberGuard-д байсан Монголын outline-ийн хуулбар. Анхны файл дахь source/licensing metadata-г хадгалсан; судалгааны geographic backdrop, cadastral хил биш. Эх файлд нарийвчилсан лицензийн мэдэгдэл дутуу бол public redistribution-оос өмнө provenance-г нягтлах хэрэгтэй.
- Shared frontend dependencies/version scaffold болон strict TS config-оос эхэлсэн; React component, styling, planner, simulation, SQLite/API implementation-ууд шинээр бичигдсэн.
- Prim, Tarjan, A*, MILP cut generation нь нийтлэг математик аргууд; нэр өөрчилсөн нь шинэ алгоритм зохиосон гэсэн утгагүй. Хамгаалалт дээр өгөгдлийн дахин ашиглалт, аргачлалын бодит өөрчлөлтийг ил тод тайлбарлана.
