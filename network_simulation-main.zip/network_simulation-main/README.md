# SteppeLink Atlas

Монголын авто зам дагасан шилэн кабелийн төлөвлөлт, сүлжээний найдвартай байдлын академик атлас.

**Энэ нь тусдаа төсөл.** `../fiberguard` доторх код, өгөгдөл, dependency, SQLite/JSON сан болон портыг өөрчлөхгүй. Shared OSRM snapshot-ийн эх сурвалжийг [ATTRIBUTION.md](ATTRIBUTION.md)-д тайлбарласан. Дизайн болон planner-ийн хэрэгжилт шинээр бичигдсэн; өгөгдөл бүхэлдээ бие даан цугларсан гэж мэдэгдэхгүй.

Цайвар газрын атлас загвар, хэвтээ цэс, газрын зурагтай төлөвлөлтийн хуудас, тасралтын лаборатори, solver-ийн баталгаа, JSON/CSV болон хэвлэх тайлантай. Default хэл монгол.

## macOS дээр ажиллуулах

Python **3.9+**, Node **22.12+** эсвэл 24 LTS, npm болон системийн `curl` хэрэгтэй. Apple Silicon дээр CBC solver нээгдэхгүй бол доорх solver шалгалтын тайлбарыг харна уу.

```bash
cd /Users/nasaa_0x/Desktop/must/steppelink-atlas
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
npm ci --prefix frontend
npm run dev
```

**http://127.0.0.1:5180** нээнэ. Backend: **http://127.0.0.1:5102/api/health**. `Ctrl+C` нь зөвхөн энэ командаас үүссэн хоёр процессыг зогсооно. Root хавтаст тусад нь npm dependency суулгах шаардлагагүй. Одоогийн workspace-д dependencies суусан тул шууд `npm run dev` ажиллана.

Эсвэл хоёр Terminal ашиглана:

```bash
# Terminal 1, төслийн root
.venv/bin/python -m backend.app
```

```bash
# Terminal 2, төслийн root
npm run dev --prefix frontend
```

`.env.example` нь боломжит орчны хувьсагчдын тайлбар; `.env` автоматаар уншихгүй. Өөрчлөх бол `export ATLAS_DATABASE=/absolute/path/atlas.sqlite3` гэх мэтээр Terminal-д өгнө. `ATLAS_PORT` өөрчлөх бол `frontend/vite.config.ts` proxy-г тааруулна. Default порт FiberGuard-ийн 5001/5173-тай давхцахгүй.

## Шалгах

```bash
npm test
npm run build
cd frontend
npx playwright install chromium
cd ..
npm run test:browser
```

Backend pytest нь түр SQLite fixture ашиглана. Browser тест шинэ Atlas-ийн локал сангийн нэг risk утгыг засч буцаадаг тул тусдаа demo database эсвэл цэвэр Atlas өгөгдөлтэй ажиллуулна. FiberGuard-д хандахгүй. Browser тестүүдэд checked-in snapshot-ийн тоонууд ашиглагдсан; гараар candidate өгөгдөл өөрчилсөн бол Atlas сангаа эх snapshot-оос сэргээж байж шалгана.

Production bundle-ийг browser-оор шалгах (5180 дээр dev server ажиллаж байвал эхлээд зогсооно):

```bash
npm run build
ATLAS_E2E_PRODUCTION=1 npm run test:browser
```

Playwright хэрэгтэй server-үүдийг өөрөө асааж, өөрөө зогсооно; ажиллаж байгаа ижил портын server-ийг reuse хийж болно. Шалгалтын бодит үр дүн [docs/VALIDATION.md](docs/VALIDATION.md)-д бий.

Solver шалгах:

```bash
.venv/bin/python -c "import pulp; print(pulp.listSolvers(onlyAvailable=True))"
```

`PULP_CBC_CMD` харагдах ёстой. PuLP **3.3.0** pin хийсэн: bundled CBC болон энэ API-д зориулсан хэрэгжилт. PuLP 4-ийн өөр API-р солихгүй. CBC executable нь тухайн Mac архитектуртай тохирох ёстой; өөр архитектуртай binary байвал тохирох Python/PuLP wheel эсвэл Rosetta орчин хэрэгтэй. Solver optimum-ийг батлаагүй үед UI infeasible/incomplete алдааг ил тод харуулна; heuristic үр дүнг optimal гэж орлуулахгүй.

## Төслийн бүтэц

```text
backend/app.py             Flask app factory, API, revision/weight cache
backend/atlas/planner.py   Prim, Tarjan, MILP cut generation, A*, metrics
backend/atlas/simulation.py тасралт, rerouting, restoration саналууд
backend/atlas/geography.py Haversine, polyline–circle intersection
backend/atlas/store.py     SQLite, validation, seed/reset
backend/atlas/roads.py     OSRM хүсэлт, disk cache, rate limit
frontend/src/App.tsx       React application, simulation state, comparisons/reports
frontend/src/NetworkMap.tsx Leaflet road geometry ба map controls
frontend/src/Inventory.tsx node/route CRUD, OSRM preview
frontend/src/api.ts        typed API helper, downloads, number formatting
frontend/src/types.ts      TypeScript domain contracts
data/mongolia-roads.json   22 хот, 45 road-following candidate зам
frontend/public/mongolia.geojson орон нутгийн map outline
scripts/benchmark.py       давтагдах тооцоо, certificate ба тасралтын жишээ
scripts/dev.mjs            тусдаа портоор хоёр server ажиллуулах
 tests/                   backend tests
frontend/e2e/              browser tests
```

## Архитектур ба алгоритм

React → REST JSON → Flask → SQLite snapshot → NetworkX / PuLP-CBC → JSON metrics → React/Leaflet/Recharts. Frontend algorithm бодохгүй. Сүлжээ сонголт бүр revision + risk weights-аар cache-лагдана. Симуляци нь stateless: frontend topology болон failed ID жагсаалтаа бүрэн явуулна. Шинэ scenario нь өмнөх failure-уудтай union хийнэ. Reset simulation нь frontend-ийн failure state-ийг цэвэрлэнэ; inventory reset нь зөвхөн шинэ Atlas SQLite-г эх seed-ээс сэргээнэ.

- **MST:** `prim_tree()` → NetworkX Prim, `weight='cost_usd'`. Нийт уртаар биш нийт deployment cost-оор minimum.
- **Bridge:** `tarjan_bridges()` → өөрийн DFS discovery / low-link хэрэгжилт; үндсэн traversal O(V+E), deterministic эрэмбэлэлтийн нэмэлт зардалтай. NetworkX-ийн bridge үр дүнтэй тестээр тулгасан.
- **2-edge:** `survivable_plan()` → binary route MILP, degree ≥ 2; disconnected component ба bridge cut-уудыг x(δ(S)) ≥ 2 нөхцөлөөр нэмж дахин solve хийнэ. MST-ийн бүх edge-ийг хадгалах шаардлагагүй. CBC бүх шатыг optimum гэж баталж, сүлжээ эцэстээ connected/bridgeless болсон үед л candidate загварын global optimum certificate буцаана. Single edge бүрийг үнэхээр авч шалгана.
- **Risk:** ижил feasible set дээр CAPEX + risk coefficient + same-SRLG pair penalty. Энэ нь загварчилсан weighted objective-ийн optimum; бодит гамшгийг даах баталгаа биш. Default weights дээр minimum cost-той **ижил сүлжээ** гарч байгаа нь зөв үр дүн; ялгаатай болгох гэж тоо зохиогоогүй.
- **Маршрут:** `route()` → NetworkX A*. Heuristic = Haversine × α; α = min(1, бүх surviving edge-ийн length / endpoint geodesic). OSRM snapping болон user route-ийн нөхцөлд доод хязгаарыг хадгална. Уртаар minimum; төхөөрөмжийн delay-г дараа нь тусад нь нэмнэ.
- **Full Mesh:** `theoretical_mesh()` → 22 choose 2 = 231 Haversine шууд холбоос, $17,500/км. Бодит замтай холихгүй, тасралтын simulation-д зөвшөөрөхгүй.

Математик болон хамгаалалтын тайлбар: [docs/TECHNICAL.md](docs/TECHNICAL.md).

## Тоон үр дүн — checked-in seed

Өгөгдлийг өөрчлөөгүй үед:

| Сүлжээ | Edge | Урт / км | Загварын CAPEX / USD | MST-ээс нэмэлт зардал | Bridge | Max загварын RTT / ms |
|---|---:|---:|---:|---:|---:|---:|
| Prim MST | 21 | 4,753.698 | 89,015,325.00 | 0% | 21 | 35.997 |
| MILP 2-edge | 22 | 6,626.102 | 122,234,284.00 | 37.32% | 0 | 37.116 |
| Risk MILP (λ=1.5, μ=0.4) | 22 | 6,626.102 | 122,234,284.00 | 37.32% | 0 | 37.116 |
| Онолын mesh | 231 | 152,410.992 | 2,667,192,361.63 | 2,896.33% | 0 | 18.445 |

2-edge-ийн уртын нэмэгдэл **39.39%**; өртгийн нэмэгдэлтэй андуурахгүй. Арван нөхцөлтэй бүсийн/SRLG scenario bank-д физик гурван topology-ийн бүтэн холболт хадгалах хувь **0%** байна. Энэ нь магадлалын тооцоо биш бөгөөд сүлжээний хязгаарлалтыг ил тод харуулж буй үр дүн.

Дахин тооцох:

```bash
.venv/bin/python -m scripts.benchmark
# эсвэл JSON artifact үүсгэх
.venv/bin/python -m scripts.benchmark > /tmp/atlas-benchmark.json
```

[docs/benchmark.json](docs/benchmark.json) нь checked-in input-оос гаргасан бодит certificate, metrics, тасралтын үр дүн.

## OSRM, CAPEX ба latency

22 хотын lat/lon, Монгол/Англи нэр, аймаг, төрөл, эрэлтийн жин JSON-д байна. Candidate pair-ууд 45 ширхэг; бүх хосыг feasible гэж үзээгүй. Snapshot нь FiberGuard-ийн OSM driving маршрутаас авсан, анхны ID `original_id` талбарт хадгалсан; шинэ ID `sl-001` гэх мэт.

Урт нь OSRM response-ийн `distance / 1000`. Geometry нь map болон disaster intersection-д хэрэглэгдэнэ. Snapshot geometry 20 м tolerance-тай хялбаршуулсан; scalar distance нь full route-ийн утга. Шинэ OSRM preview нь full geometry авна. `roads.fetch_road()` системийн certificate-verified `curl`-аар keyless HTTPS хүсэлт илгээнэ, амжилттай хариуг URL-ийн SHA256 түлхүүртэй `data/road-cache/*.json` файлд atomic байдлаар хадгална. Public endpoint-д process тус бүр дор хаяж 1.1 секундийн зайтай хүсэлт хийнэ. Алдаа гарвал шулуун зам зохиож орлуулахгүй. Offline үед checked-in snapshot, solver, simulation ажиллана; tile ба font ачаалахгүй байж болно, local outline/road геометр хэвээр харагдана.

CAPEX = distance × terrain rate (steppe $17,500; mountain $23,500; gobi $15,000/км; user-created river $21,000, urban $26,000). Эдгээр нь академик таамаг. One-way propagation = distance / 200 ms; equipment one-way = hop count × 0.2 ms; modeled RTT = 2 × (propagation + equipment). 50 ms зорилгыг шалгадаг ч хэмжсэн ping гэж тайлбарлахгүй.

Өөр урт оруулахдаа **Өгөгдлийн сан → засах → user_estimate** эсвэл **validated_route + эх сурвалжийн тайлбар** сонгоно. OSRM гаралтай гэж нэрлэх бол unchanged cached snapshot эсвэл шинэ бодит OSRM preview-тэй distance/geometry таарах ёстой. Geometry-ийн төгсгөлүүд хотуудаас 2 км дотор байна. Энэ нь баримтын үнэн зөвийг хараат бусаар баталгаажуулах үйлчилгээ биш; validated_route нь хэрэглэгчийн гаргаж өгсөн нотолгоонд суурилна.

## REST API

| Method | Endpoint | Үйлдэл |
|---|---|---|
| GET | `/api/health` | service, algorithms |
| GET | `/api/bootstrap` | dataset, 4 plan, metrics, certificates, settings |
| POST | `/api/plan` | `{risk_weight:1.5, diversity_weight:0.4}` |
| POST | `/api/failures` | topology, event, previous_failed, applied weights |
| POST | `/api/route` | topology, source, target, failed_ids, applied weights |
| GET/POST | `/api/inventory/nodes` | хот жагсаах/үүсгэх |
| PUT/DELETE | `/api/inventory/nodes/<id>` | хот засах/устгах |
| GET/POST | `/api/inventory/routes` | зам жагсаах/үүсгэх |
| PUT/DELETE | `/api/inventory/routes/<id>` | зам засах/устгах |
| POST | `/api/road-preview` | `{source:'ub', target:'darkhan'}` |
| POST | `/api/reset` | `{confirm:'RESET_ATLAS'}` зөвхөн Atlas inventory reset |

Тасралтын жишээ:

```bash
curl http://127.0.0.1:5102/api/failures \
  -H 'Content-Type: application/json' \
  -d '{"topology":"resilient","event":{"kind":"cut","edge_ids":["sl-028"]},"previous_failed":[]}'
```

`flood`/`earthquake`: `center:[47.918,106.917], radius_km:80, severity:1`; `srlg`: `group:'western-pass'`. Тойрогтой polyline-ийн аль ч segment огтолбол зам бүхэлдээ failed. Flood/earthquake нь ижил geometric failure rule ашигладаг. Severity нь радиусын үржүүлэгч; магниуд биш. Recovery нь component graph-ийн Prim санал; хэрэгжүүлээгүй санал нь бодит connectivity-г өөрчлөхгүй.

## Demo ба хязгаарлалт

Хуваалцах source ZIP: `.venv/bin/python -m scripts.package` → төслийн хажууд `steppelink-atlas.zip`. Dependency, runtime database/cache, `.env` орохгүй; хүлээн авсан хүн дээрх installation алхмыг ажиллуулна.

Таван минутын demo: [docs/DEMO.md](docs/DEMO.md). Гол нь logical redundancy, geographic correlated failure, latency penalty-г ялгаж харуулах.

Энэ хувилбар local академик хэрэглээнд зориулсан. Нэвтрэх эрх, олон хэрэглэгчийн тусдаа simulation хадгалалт, capacity/traffic assignment, бодит flood/earthquake feed, probability-based reliability, terrain survey, баталгаажсан кабель, backup latency-тай survivable routing constraint, MILP optimality gap dashboard, routed mesh байхгүй. PDF нь browser-ийн print-to-PDF; тусгай PDF renderer байхгүй. Costs/demands/risk/SRLG нь estimated. MILP-д 25 секундийн solver budget, 100 separation round, 60 node/160 candidate-ийн академик хязгаар бий. Heuristic fallback хийхгүй; боломжгүй/дуусаагүй үр дүнг error-оор харуулна.

Production frontend build: `frontend/dist`. Local production preview: `npm run preview --prefix frontend`. Backend WSGI ажиллуулах бол root-оос:

```bash
.venv/bin/python -m gunicorn 'backend.app:create_app()' --bind 127.0.0.1:5102 --workers 1 --threads 4 --timeout 120
```

Бодит public deployment-д reverse proxy, TLS, authentication, edit authorization, shared solver job queue, monitoring нэмэх шаардлагатай. Vite preview нь permanent public hosting server биш.
