"""SteppeLink Atlas application package."""
