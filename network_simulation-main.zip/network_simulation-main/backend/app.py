"""Flask REST interface. Run: python -m backend.app, from repository root."""
import logging
import os
import threading
from pathlib import Path

from flask import Flask, jsonify, request
from flask_cors import CORS
from werkzeug.exceptions import HTTPException

from .atlas.planner import PlanningError, prim_tree, survivable_plan, theoretical_mesh, metrics, route, TERRAIN_RATE
from .atlas.roads import fetch_road
from .atlas.simulation import simulate
from .atlas.store import Store, number

ROOT = Path(__file__).resolve().parents[1]


def create_app(database=None, seed=None):
    app = Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = 6 * 1024 * 1024
    CORS(app, resources={r'/api/*': {'origins': ['http://localhost:5180', 'http://127.0.0.1:5180']}})
    store = Store(database or os.getenv('ATLAS_DATABASE', str(ROOT / 'data/atlas.sqlite3')), seed or ROOT / 'data/mongolia-roads.json')
    app.extensions['store'] = store
    cache, lock = {}, threading.RLock()

    def body():
        data = request.get_json()
        if not isinstance(data, dict):
            raise PlanningError('Request body must be a JSON object.')
        return data

    def plans(snapshot, risk=1.5, diversity=0.4):
        key = (snapshot['revision'], risk, diversity)
        with lock:
            if key in cache:
                return cache[key]
            nodes, edges = snapshot['nodes'], snapshot['edges']
            result = {}
            specifications = [('tree', 'Prim MST'), ('resilient', 'MILP / 2-edge'), ('risk', 'MILP / Risk + SRLG'), ('mesh', 'Theoretical Full Mesh')]
            for name, title in specifications:
                try:
                    cert = None
                    if name == 'tree':
                        selected = prim_tree(nodes, edges)
                    elif name == 'mesh':
                        selected = theoretical_mesh(nodes)
                    else:
                        selected, cert = survivable_plan(nodes, edges, risk if name == 'risk' else 0, diversity if name == 'risk' else 0)
                    result[name] = {'id': name, 'title': title, 'edge_ids': [e['id'] for e in selected], 'metrics': metrics(nodes, selected), 'certificate': cert, 'feasible': True}
                    if name == 'mesh':
                        result[name]['theoretical_edges'] = selected
                except PlanningError as exc:
                    result[name] = {'id': name, 'title': title, 'edge_ids': [], 'metrics': None, 'certificate': None, 'feasible': False, 'error': str(exc)}
            base = result['tree']['metrics']['capex_usd'] if result['tree']['feasible'] else None
            for plan in result.values():
                if plan['metrics']:
                    plan['metrics']['added_cost_pct'] = round((plan['metrics']['capex_usd'] / base - 1) * 100, 2) if base else None
            if len(cache) >= 12:
                cache.clear()
            cache[key] = result
            return result

    def context(data):
        snapshot = store.snapshot()
        kind = data.get('topology', 'resilient')
        available = plans(snapshot, number(data.get('risk_weight', 1.5), 'risk_weight', 0, 5), number(data.get('diversity_weight', 0.4), 'diversity_weight', 0, 2))
        if kind not in available:
            raise PlanningError('Unknown topology.')
        if kind == 'mesh':
            raise PlanningError('Theoretical links are not physical infrastructure; simulations use candidate networks only.')
        plan = available[kind]
        if not plan['feasible']:
            raise PlanningError(plan['error'])
        selected = [e for e in snapshot['edges'] if e['id'] in plan['edge_ids']]
        return snapshot, selected

    @app.errorhandler(PlanningError)
    def invalid(exc):
        return jsonify(error={'code': 'validation_error', 'message': str(exc)}), 422

    @app.errorhandler(HTTPException)
    def http_error(exc):
        return jsonify(error={'code': exc.name, 'message': exc.description}), exc.code

    @app.errorhandler(Exception)
    def server_error(exc):
        logging.exception('Atlas request failed')
        return jsonify(error={'code': 'internal_error', 'message': 'Unexpected server error. See backend logs.'}), 500

    @app.get('/api/health')
    def health():
        return jsonify(status='ok', project='SteppeLink Atlas', database='sqlite', algorithms=['Prim', 'Tarjan', 'MILP cut generation', 'A*'])

    @app.get('/api/bootstrap')
    def bootstrap():
        snapshot = store.snapshot()
        return jsonify(**snapshot, plans=plans(snapshot), settings={'equipment_ms_per_hop': 0.2, 'fiber_speed_km_s': 200000, 'terrain_rates': TERRAIN_RATE, 'reference': 'ub'})

    @app.post('/api/plan')
    def optimize():
        data = body()
        snapshot = store.snapshot()
        return jsonify(plans=plans(snapshot, number(data.get('risk_weight', 1.5), 'risk_weight', 0, 5), number(data.get('diversity_weight', 0.4), 'diversity_weight', 0, 2)))

    @app.post('/api/failures')
    def failures():
        data = body()
        snapshot, selected = context(data)
        previous = data.get('previous_failed', [])
        if not isinstance(previous, list) or any(not isinstance(e, str) for e in previous):
            raise PlanningError('previous_failed must be a list of route IDs.')
        event = data.get('event', {})
        if not isinstance(event, dict):
            raise PlanningError('event must be a JSON object.')
        return jsonify(simulate(snapshot['nodes'], snapshot['edges'], selected, event, previous))

    @app.post('/api/route')
    def shortest_path():
        data = body()
        snapshot, selected = context(data)
        failed = data.get('failed_ids', [])
        if not isinstance(failed, list) or any(not isinstance(e, str) for e in failed) or set(failed) - {e['id'] for e in selected}:
            raise PlanningError('failed_ids must be selected route IDs.')
        source, target = data.get('source', 'ub'), data.get('target')
        if not isinstance(source, str) or not isinstance(target, str):
            raise PlanningError('source and target must be city IDs.')
        return jsonify(before=route(snapshot['nodes'], selected, source, target), after=route(snapshot['nodes'], selected, source, target, failed))

    @app.route('/api/inventory/<kind>', methods=['GET', 'POST'])
    def inventory(kind):
        if kind not in ('nodes', 'routes'):
            raise PlanningError('Inventory kind must be nodes or routes.')
        if request.method == 'GET':
            return jsonify(items=store.snapshot()['nodes' if kind == 'nodes' else 'edges'])
        result = store.save_node(body()) if kind == 'nodes' else store.save_route(body())
        return jsonify(item=result), 201

    @app.route('/api/inventory/<kind>/<key>', methods=['PUT', 'DELETE'])
    def inventory_item(kind, key):
        if kind not in ('nodes', 'routes'):
            raise PlanningError('Inventory kind must be nodes or routes.')
        if request.method == 'DELETE':
            store.delete(kind, key)
            return jsonify(deleted=key)
        data = dict(body(), id=key)
        return jsonify(item=store.save_node(data, True) if kind == 'nodes' else store.save_route(data, True))

    @app.post('/api/road-preview')
    def road_preview():
        data = body()
        snapshot = store.snapshot()
        nodes = {n['id']: n for n in snapshot['nodes']}
        source, target = data.get('source'), data.get('target')
        if not isinstance(source, str) or not isinstance(target, str) or source == target or source not in nodes or target not in nodes:
            raise PlanningError('Choose two different existing city IDs.')
        return jsonify(fetch_road(nodes[source], nodes[target], ROOT / 'data/road-cache'))

    @app.post('/api/reset')
    def reset():
        if body().get('confirm') != 'RESET_ATLAS':
            raise PlanningError('Explicit confirmation string RESET_ATLAS is required.')
        store.reset()
        cache.clear()
        return jsonify(status='reset')

    return app


if __name__ == '__main__':
    create_app().run(host='127.0.0.1', port=int(os.getenv('ATLAS_PORT', '5102')), debug=False)
