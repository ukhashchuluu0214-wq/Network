"""SQLite repository. The checked-in source snapshot is never mutated."""
import json
import hashlib
from urllib.parse import urlsplit
import math
import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from .planner import PlanningError, TERRAIN_RATE
from .geography import haversine


def number(value, label, minimum, maximum):
    if isinstance(value, bool):
        raise PlanningError('%s must be a number.' % label)
    try:
        result = float(value)
    except (ValueError, TypeError):
        raise PlanningError('%s must be a number.' % label)
    if not math.isfinite(result) or not minimum <= result <= maximum:
        raise PlanningError('%s must be between %s and %s.' % (label, minimum, maximum))
    return result


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,50}', value):
        raise PlanningError('ID: use 1–50 letters, numbers, underscore or hyphen.')
    return value


def text(value, label):
    if not isinstance(value, str) or not value.strip() or len(value) > 200:
        raise PlanningError('%s is required (max 200 characters).' % label)
    return value.strip()


class Store:
    def __init__(self, path, seed):
        self.path, self.seed = str(path), Path(seed)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as con:
            con.executescript('''CREATE TABLE IF NOT EXISTS nodes(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS routes(id TEXT PRIMARY KEY, source TEXT NOT NULL REFERENCES nodes(id), target TEXT NOT NULL REFERENCES nodes(id), payload TEXT NOT NULL, UNIQUE(source,target));
              CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);''')
            if not con.execute("SELECT value FROM meta WHERE key='initialized'").fetchone():
                self._seed(con)

    @contextmanager
    def connection(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.execute('PRAGMA foreign_keys=ON')
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def _seed(self, con):
        data = json.loads(self.seed.read_text())
        for node in data['nodes']:
            con.execute('INSERT INTO nodes VALUES (?,?)', (node['id'], json.dumps(node, ensure_ascii=False)))
        for edge in data['edges']:
            con.execute('INSERT INTO routes VALUES (?,?,?,?)', (edge['id'], edge['source'], edge['target'], json.dumps(edge, ensure_ascii=False)))
        con.execute("INSERT OR REPLACE INTO meta VALUES ('initialized','1')")
        self._bump(con)

    @staticmethod
    def _bump(con):
        con.execute("INSERT INTO meta VALUES ('revision','1') ON CONFLICT(key) DO UPDATE SET value=CAST(value AS INTEGER)+1")

    def snapshot(self):
        with self.connection() as con:
            nodes = [json.loads(row[0]) for row in con.execute('SELECT payload FROM nodes ORDER BY rowid')]
            edges = [json.loads(row[0]) for row in con.execute('SELECT payload FROM routes ORDER BY id')]
            revision = int(con.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0])
        metadata = json.loads(self.seed.read_text())['metadata']
        return {'nodes': nodes, 'edges': edges, 'revision': revision, 'metadata': metadata}

    def save_node(self, payload, update=False):
        key = identifier(payload.get('id'))
        node = {k: text(payload.get(k), k) for k in ('name_mn', 'name_en', 'province')}
        node.update(id=key, lat=number(payload.get('lat'), 'lat', 40, 53), lon=number(payload.get('lon'), 'lon', 87, 121), node_type=payload.get('node_type', 'regional'), traffic_demand_mbps=number(payload.get('traffic_demand_mbps', 500), 'demand', 1, 1000000))
        if node['node_type'] not in ('core', 'regional'):
            raise PlanningError('node_type must be core or regional.')
        with self.connection() as con:
            existing = con.execute('SELECT payload FROM nodes WHERE id=?', (key,)).fetchone()
            if bool(existing) != update:
                raise PlanningError('Node does not exist.' if update else 'Node ID already exists.')
            if update:
                old = json.loads(existing[0])
                connected = con.execute('SELECT id FROM routes WHERE source=? OR target=?', (key, key)).fetchone()
                if connected and (old['lat'], old['lon']) != (node['lat'], node['lon']):
                    raise PlanningError('Remove connected routes before moving this city; road geometry would become invalid.')
                con.execute('UPDATE nodes SET payload=? WHERE id=?', (json.dumps(node, ensure_ascii=False), key))
            else:
                con.execute('INSERT INTO nodes VALUES (?,?)', (key, json.dumps(node, ensure_ascii=False)))
            self._bump(con)
        return node

    def save_route(self, payload, update=False):
        key = identifier(payload.get('id'))
        source, target = identifier(payload.get('source')), identifier(payload.get('target'))
        if source == target:
            raise PlanningError('Self-links are not candidate routes.')
        terrain = payload.get('terrain', 'steppe')
        if not isinstance(terrain, str) or terrain not in TERRAIN_RATE:
            raise PlanningError('Unknown terrain type.')
        with self.connection() as con:
            existing = con.execute('SELECT payload FROM routes WHERE id=?', (key,)).fetchone()
            if bool(existing) != update:
                raise PlanningError('Route does not exist.' if update else 'Route ID already exists.')
            endpoints = {row[0] for row in con.execute('SELECT id FROM nodes WHERE id IN (?,?)', (source, target))}
            if len(endpoints) != 2:
                raise PlanningError('Both endpoints must exist.')
            duplicate = con.execute('SELECT id FROM routes WHERE ((source=? AND target=?) OR (source=? AND target=?)) AND id!=?', (source, target, target, source, key)).fetchone()
            if duplicate:
                raise PlanningError('An undirected route already joins those cities.')
            old = json.loads(existing[0]) if existing else {}
            if update and (source, target) != (old['source'], old['target']):
                raise PlanningError('Delete and recreate a route to change its endpoints.')
            geometry = payload.get('geometry', old.get('geometry'))
            if not isinstance(geometry, list) or not 2 <= len(geometry) <= 25000:
                raise PlanningError('Provide 2–25000 [lat,lon] road geometry points, or import an OSRM alignment.')
            if any(not isinstance(p, list) or len(p) != 2 for p in geometry):
                raise PlanningError('Every geometry point must be [latitude, longitude].')
            geometry = [[number(p[0], 'geometry latitude', -90, 90), number(p[1], 'geometry longitude', -180, 180)] for p in geometry]
            positions = {row[0]: json.loads(row[1]) for row in con.execute('SELECT id,payload FROM nodes WHERE id IN (?,?)', (source, target))}
            coords = [[positions[k]['lat'], positions[k]['lon']] for k in (source, target)]
            if not (max(haversine(geometry[0], coords[0]), haversine(geometry[-1], coords[1])) <= 2 or max(haversine(geometry[-1], coords[0]), haversine(geometry[0], coords[1])) <= 2):
                raise PlanningError('Geometry endpoints must be within 2 km of the selected cities.')
            distance = number(payload.get('distance_km', old.get('distance_km')), 'distance_km', 0.01, 15000)
            provenance = payload.get('distance_source', old.get('distance_source', 'user_estimate'))
            if provenance not in ('osm_road_route', 'validated_route', 'user_estimate'):
                raise PlanningError('distance_source must be osm_road_route, validated_route or user_estimate.')
            if provenance == 'osm_road_route':
                unchanged = old.get('distance_source') == provenance and old.get('geometry') == geometry and old.get('distance_km') == distance
                routing = payload.get('routing', {})
                request_url = routing.get('request_url', '') if isinstance(routing, dict) else ''
                cache_file = self.seed.parent / 'road-cache' / (hashlib.sha256(request_url.encode()).hexdigest() + '.json')
                expected_coords = '%.6f,%.6f;%.6f,%.6f' % (coords[0][1], coords[0][0], coords[1][1], coords[1][0])
                verified_preview = False
                if cache_file.exists() and urlsplit(request_url).path.endswith('/route/v1/driving/' + expected_coords):
                    cached = json.loads(cache_file.read_text())
                    verified_preview = cached['distance_km'] == distance and cached['geometry'] == geometry
                if not unchanged and not verified_preview:
                    raise PlanningError('Changed road length/geometry needs a fresh OSRM preview, or user_estimate/validated_route provenance.')
            if payload.get('shared_risk_group') is not None:
                text(payload.get('shared_risk_group'), 'shared_risk_group')
            if provenance == 'validated_route' and not payload.get('validation_note'):
                raise PlanningError('A validated route requires a survey/source note.')
            edge = dict(old, id=key, source=source, target=target, distance_km=distance, terrain=terrain, risk_score=number(payload.get('risk_score', old.get('risk_score', 0.4)), 'risk_score', 0, 1), disaster_exposure=number(payload.get('disaster_exposure', old.get('disaster_exposure', 0.3)), 'disaster_exposure', 0, 1), corridor_id=text(payload.get('corridor_id', old.get('corridor_id', key)), 'corridor_id'), shared_risk_group=payload.get('shared_risk_group') or None, geometry=geometry, distance_source=provenance, status='planned', latency_ms=distance / 200, cost_usd=round(distance * TERRAIN_RATE[terrain], 2))
            if payload.get('routing'):
                edge['routing'] = payload['routing']
            if payload.get('validation_note'):
                edge['validation_note'] = text(payload['validation_note'], 'validation_note')
            if update:
                con.execute('UPDATE routes SET payload=? WHERE id=?', (json.dumps(edge, ensure_ascii=False), key))
            else:
                con.execute('INSERT INTO routes VALUES (?,?,?,?)', (key, source, target, json.dumps(edge, ensure_ascii=False)))
            self._bump(con)
        return edge

    def delete(self, kind, key):
        identifier(key)
        table = 'nodes' if kind == 'nodes' else 'routes'
        if key == 'ub' and table == 'nodes':
            raise PlanningError('Keep the Ulaanbaatar reference node.')
        with self.connection() as con:
            if table == 'nodes' and con.execute('SELECT id FROM routes WHERE source=? OR target=?', (key, key)).fetchone():
                raise PlanningError('Delete connected routes before deleting this city.')
            cursor = con.execute('DELETE FROM %s WHERE id=?' % table, (key,))
            if not cursor.rowcount:
                raise PlanningError('Item not found.')
            self._bump(con)

    def reset(self):
        with self.connection() as con:
            con.execute('DELETE FROM routes')
            con.execute('DELETE FROM nodes')
            self._seed(con)
