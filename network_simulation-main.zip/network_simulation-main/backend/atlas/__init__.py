"""Independent planning, persistence and geographic simulation domain."""
