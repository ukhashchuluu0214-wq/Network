"""Geographic approximations; coordinates everywhere are [latitude, longitude]."""
import math


def haversine(a, b):
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp, dl = p2 - p1, math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0088 * 2 * math.asin(min(1, math.sqrt(h)))


def intersects_circle(geometry, center, radius_km):
    """Point/segment distance in a local equirectangular plane, not endpoint-only.

    Appropriate for regional planning, not a geodetic hazard/engineering model.
    """
    lat, lon = center
    scale_x = 111.195 * math.cos(math.radians(lat))
    pts = [((p[1] - lon) * scale_x, (p[0] - lat) * 111.195) for p in geometry]
    if any(math.hypot(x, y) <= radius_km for x, y in pts):
        return True
    for (ax, ay), (bx, by) in zip(pts, pts[1:]):
        dx, dy = bx - ax, by - ay
        norm = dx * dx + dy * dy
        t = max(0, min(1, -(ax * dx + ay * dy) / norm)) if norm else 0
        if math.hypot(ax + t * dx, ay + t * dy) <= radius_km:
            return True
    return False
