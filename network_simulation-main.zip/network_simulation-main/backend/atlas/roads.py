"""Keyless OSRM adapter. Cache successful responses; never invent a road route."""
import hashlib
import json
import os
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

from .planner import PlanningError

_LOCK = threading.Lock()
_LAST_CALL = 0.0


def fetch_road(a, b, cache_dir):
    global _LAST_CALL
    server = os.getenv('ATLAS_OSRM_URL', 'https://routing.openstreetmap.de/routed-car').rstrip('/')
    coordinates = '%.6f,%.6f;%.6f,%.6f' % (a['lon'], a['lat'], b['lon'], b['lat'])
    url = server + '/route/v1/driving/' + coordinates + '?' + urlencode({'overview': 'full', 'geometries': 'geojson', 'steps': 'false', 'alternatives': 'false', 'radiuses': '1000;1000'})
    key = hashlib.sha256(url.encode()).hexdigest()
    directory = Path(cache_dir)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / (key + '.json')
    with _LOCK:
        if path.exists():
            data = json.loads(path.read_text())
            data['routing']['cache_hit'] = True
            return data
        delay = 1.1 - (time.monotonic() - _LAST_CALL)
        if delay > 0:
            time.sleep(delay)
        try:
            # macOS system Python may use older LibreSSL; curl uses the OS trust store.
            result = subprocess.run(['curl', '--fail', '--silent', '--show-error', '--max-time', '35', '--max-filesize', '10000000', url], capture_output=True, text=True, timeout=40, check=True)
            raw = json.loads(result.stdout)
        except (subprocess.SubprocessError, OSError, ValueError) as exc:
            raise PlanningError('OSRM unavailable. Existing cached planning data remains usable: %s' % type(exc).__name__) from exc
        finally:
            _LAST_CALL = time.monotonic()
        if raw.get('code') != 'Ok' or not raw.get('routes'):
            raise PlanningError('OSRM returned no drivable route; no straight-line fallback was created.')
        route = raw['routes'][0]
        data = {'distance_km': round(route['distance'] / 1000, 3), 'geometry': [[lat, lon] for lon, lat in route['geometry']['coordinates']], 'distance_source': 'osm_road_route', 'routing': {'provider': 'OSRM / OSM', 'request_url': url, 'fetched_at': datetime.now(timezone.utc).isoformat(), 'cache_hit': False, 'surface_verified': False, 'fiber_route_verified': False}}
        temporary = path.with_suffix('.tmp')
        temporary.write_text(json.dumps(data))
        temporary.replace(path)
        return data
