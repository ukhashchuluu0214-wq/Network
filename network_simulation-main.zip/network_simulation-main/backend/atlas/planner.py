"""Prim, Tarjan, cut-generation MILP and admissible A*; no FiberGuard planner imports."""
import itertools
import time
from collections import Counter

import networkx as nx
import pulp

from .geography import haversine, intersects_circle

EQUIPMENT_MS_PER_HOP = 0.2
TERRAIN_RATE = {'steppe': 17500, 'mountain': 23500, 'gobi': 15000, 'river': 21000, 'urban': 26000}


class PlanningError(ValueError):
    pass


def graph(nodes, edges, excluded=()):
    g = nx.Graph()
    g.add_nodes_from((n['id'], n) for n in nodes)
    g.add_edges_from((e['source'], e['target'], dict(e)) for e in edges if e['id'] not in excluded)
    return g


def tarjan_bridges(g):
    """DFS discovery/low-link algorithm with sorted traversal for deterministic reporting."""
    discovery, low, result = {}, {}, []

    def visit(u, parent):
        discovery[u] = low[u] = len(discovery)
        for v in sorted(g.neighbors(u)):
            if v == parent:
                continue
            if v not in discovery:
                visit(v, u)
                low[u] = min(low[u], low[v])
                if low[v] > discovery[u]:
                    result.append(g[u][v]['id'])
            else:
                low[u] = min(low[u], discovery[v])
    for u in sorted(g):
        if u not in discovery:
            visit(u, None)
    return sorted(result)


def prim_tree(nodes, edges):
    g = graph(nodes, edges)
    if not nx.is_connected(g):
        raise PlanningError('Candidate graph disconnected: a spanning tree is infeasible.')
    tree = nx.minimum_spanning_tree(g, algorithm='prim', weight='cost_usd')
    return sorted((dict(d) for _, _, d in tree.edges(data=True)), key=lambda e: e['id'])


def survivable_plan(nodes, edges, risk_weight=0.0, diversity_weight=0.0, time_limit=25):
    """Globally minimum linear objective on the given candidate graph, conditional
    on CBC proving each relaxation optimal. Degree constraints + violated cuts
    x(delta(S)) >= 2. A final connected bridgeless solution certifies feasibility.
    Unlike MST augmentation, tree edges are NOT required to be retained.
    """
    baseline = graph(nodes, edges)
    if not nx.is_connected(baseline) or tarjan_bridges(baseline):
        raise PlanningError('Candidate corridors cannot support a 2-edge-connected network.')
    if len(nodes) > 60 or len(edges) > 160:
        raise PlanningError('Academic solver limit: at most 60 nodes and 160 candidate routes.')
    model = pulp.LpProblem('atlas_survivable_corridors', pulp.LpMinimize)
    ordered = sorted(edges, key=lambda e: e['id'])
    x = {e['id']: pulp.LpVariable('route_%s' % i, cat='Binary') for i, e in enumerate(ordered)}
    # Objective in millions of USD for numerical stability. Risk is a proxy, not probability.
    terms = [e['cost_usd'] / 1e6 * (1 + risk_weight * (0.6 * e['risk_score'] + 0.4 * e.get('disaster_exposure', 0))) * x[e['id']] for e in ordered]
    # Pairwise SRLG co-selection penalty, exact binary AND linearization.
    pairs = 0
    if diversity_weight:
        for a, b in itertools.combinations(ordered, 2):
            if a.get('shared_risk_group') and a.get('shared_risk_group') == b.get('shared_risk_group'):
                y = pulp.LpVariable('shared_pair_%s' % pairs, cat='Binary')
                model += y >= x[a['id']] + x[b['id']] - 1
                model += y <= x[a['id']]
                model += y <= x[b['id']]
                terms.append(diversity_weight * min(a['cost_usd'], b['cost_usd']) / 1e6 * y)
                pairs += 1
    model += pulp.lpSum(terms)
    for n in nodes:
        model += pulp.lpSum(x[e['id']] for e in ordered if n['id'] in (e['source'], e['target'])) >= 2
    start, seen, trace = time.monotonic(), set(), []
    all_ids = frozenset(n['id'] for n in nodes)
    for iteration in range(1, 101):
        remaining = time_limit - (time.monotonic() - start)
        if remaining <= 0:
            raise PlanningError('Solver time budget exceeded; no optimality certificate returned.')
        status = model.solve(pulp.PULP_CBC_CMD(msg=False, threads=1, timeLimit=remaining, gapRel=0, gapAbs=0, options=['randomSeed 42']))
        if status != pulp.LpStatusOptimal or model.sol_status != pulp.LpSolutionOptimal:
            raise PlanningError('CBC did not prove an optimum: %s. Try smaller weights or fewer corridors.' % pulp.LpStatus[status])
        selected = [e for e in ordered if x[e['id']].value() > 0.5]
        g = graph(nodes, selected)
        components = list(nx.connected_components(g))
        bridges = tarjan_bridges(g)
        trace.append({'round': iteration, 'objective_musd': round(pulp.value(model.objective), 6), 'edges': len(selected), 'components': len(components), 'bridges': len(bridges), 'cuts_before': len(seen)})
        if len(components) == 1 and not bridges:
            verified = all(nx.is_connected(graph(nodes, selected, [e['id']])) for e in selected)
            if not verified:
                raise PlanningError('Single-cut verification failed; refusing an optimality certificate.')
            return selected, {'solver': 'CBC / PuLP 3.3', 'status': 'optimal', 'global_optimum': True, 'scope': 'Given candidate corridors and declared linear objective, within solver numerical tolerance', 'rounds': iteration, 'cuts': len(seen), 'trace': trace, 'verified_single_cuts': verified, 'risk_weight': risk_weight, 'diversity_weight': diversity_weight, 'shared_pairs': pairs, 'objective_musd': round(pulp.value(model.objective), 6)}
        partitions = components if len(components) > 1 else []
        if len(components) == 1:
            for edge in selected:
                if edge['id'] in bridges:
                    h = graph(nodes, selected, [edge['id']])
                    partitions.append(set(nx.node_connected_component(h, edge['source'])))
        new_cuts = 0
        for partition in partitions:
            s = frozenset(partition)
            complement = all_ids - s
            key = min(tuple(sorted(s)), tuple(sorted(complement)))
            if key in seen:
                continue
            seen.add(key)
            crossing = [x[e['id']] for e in ordered if (e['source'] in s) != (e['target'] in s)]
            model += pulp.lpSum(crossing) >= 2
            new_cuts += 1
        if not new_cuts:
            raise PlanningError('Cut separation stalled; no feasible certificate.')
    raise PlanningError('Cut generation iteration limit exceeded.')


def theoretical_mesh(nodes):
    edges = []
    for i, (a, b) in enumerate(itertools.combinations(nodes, 2)):
        distance = haversine([a['lat'], a['lon']], [b['lat'], b['lon']])
        edges.append({'id': 'theory-%03d' % i, 'source': a['id'], 'target': b['id'], 'distance_km': distance, 'cost_usd': distance * 17500, 'risk_score': 0, 'disaster_exposure': 0, 'terrain': 'theoretical', 'corridor_id': 'THEORETICAL', 'shared_risk_group': None, 'geometry': [[a['lat'], a['lon']], [b['lat'], b['lon']]], 'distance_source': 'haversine_theoretical', 'status': 'theoretical'})
    return edges


def route(nodes, edges, source, target, failed=()):
    g = graph(nodes, edges, failed)
    if source not in g or target not in g:
        raise PlanningError('Unknown source or destination node.')
    coords = {n['id']: [n['lat'], n['lon']] for n in nodes}
    # OSRM snaps may produce a road length shorter than city-centre geodesic.
    # Scaling ensures consistency/admissibility even in that case.
    ratios = [e['distance_km'] / max(haversine(coords[e['source']], coords[e['target']]), 1e-9) for _, _, e in g.edges(data=True)]
    alpha = min([1.0] + ratios)
    try:
        path = nx.astar_path(g, source, target, heuristic=lambda a, b: alpha * haversine(coords[a], coords[b]), weight='distance_km')
    except nx.NetworkXNoPath:
        return {'reachable': False, 'nodes': [], 'edge_ids': [], 'distance_km': None, 'propagation_one_way_ms': None, 'propagation_rtt_ms': None, 'equipment_one_way_ms': None, 'modeled_rtt_ms': None}
    links = [g[a][b] for a, b in zip(path, path[1:])]
    distance = sum(e['distance_km'] for e in links)
    prop = distance / 200.0
    equipment = len(links) * EQUIPMENT_MS_PER_HOP
    return {'reachable': True, 'nodes': path, 'edge_ids': [e['id'] for e in links], 'distance_km': round(distance, 3), 'propagation_one_way_ms': round(prop, 5), 'propagation_rtt_ms': round(2 * prop, 5), 'equipment_one_way_ms': round(equipment, 5), 'modeled_rtt_ms': round(2 * (prop + equipment), 5), 'algorithm': 'A* / scaled admissible geodesic heuristic'}


def metrics(nodes, edges, reference='ub'):
    g = graph(nodes, edges)
    theoretical = bool(edges) and all(e.get('status') == 'theoretical' for e in edges)
    bridges = tarjan_bridges(g)
    connected = nx.is_connected(g)
    # Every selected edge is actually removed and connectivity checked.
    survival = sum(nx.is_connected(graph(nodes, edges, [e['id']])) for e in edges)
    # Reproducible small scenario bank; this is not a probability forecast.
    by_group = {e.get('shared_risk_group') for e in edges if e.get('shared_risk_group')}
    scenarios = [[e['id'] for e in edges if e.get('shared_risk_group') == group] for group in sorted(by_group)]
    scenarios += [[e['id'] for e in edges if intersects_circle(e['geometry'], [n['lat'], n['lon']], 65)] for n in nodes[::4]]
    # Include only scenarios that strike infrastructure, and count singles too with explicit methodology.
    scenarios = [] if theoretical else [s for s in scenarios if s]
    survived = sum(nx.is_connected(graph(nodes, edges, s)) for s in scenarios)
    rtts = [route(nodes, edges, a['id'], b['id'])['modeled_rtt_ms'] for a, b in itertools.combinations(nodes, 2)]
    maximum = max((r for r in rtts if r is not None), default=0)
    corridor_counts = Counter(e.get('shared_risk_group') or e['corridor_id'] for e in edges)
    return {'node_count': len(nodes), 'edge_count': len(edges), 'distance_km': round(sum(e['distance_km'] for e in edges), 3), 'capex_usd': round(sum(e['cost_usd'] for e in edges), 2), 'bridge_count': len(bridges), 'bridge_ids': bridges, 'components': nx.number_connected_components(g), 'single_survival_pct': round(100 * survival / len(edges), 2) if edges else 0, 'scenario_survival_pct': None if theoretical else round(100 * survived / len(scenarios), 2) if scenarios else 0, 'scenario_count': len(scenarios), 'max_rtt_ms': round(maximum, 3), 'rtt_under_50': connected and maximum < 50, 'corridor_diversity': 0 if theoretical else len(corridor_counts), 'largest_srlg_links': 0 if theoretical else max(corridor_counts.values(), default=0), 'connected': connected}
