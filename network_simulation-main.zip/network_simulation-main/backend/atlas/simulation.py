"""Stateless failure simulation; no baseline mutation, no fictional restoration."""
import networkx as nx

from .geography import intersects_circle
from .planner import PlanningError, graph, route, tarjan_bridges
from .store import number


def disaster_ids(edges, event):
    kind = event.get('kind', 'cut')
    if kind == 'cut':
        ids = event.get('edge_ids', [])
        if not isinstance(ids, list) or any(not isinstance(e, str) for e in ids):
            raise PlanningError('edge_ids must be a list of route IDs.')
        unknown = set(ids) - {e['id'] for e in edges}
        if unknown:
            raise PlanningError('Route not in this topology: %s' % ', '.join(sorted(unknown)))
        return sorted(set(ids)), None
    if kind == 'srlg':
        group = event.get('group')
        if not group or group not in {e.get('shared_risk_group') for e in edges}:
            raise PlanningError('Choose an SRLG present in this topology.')
        return sorted(e['id'] for e in edges if e.get('shared_risk_group') == group), None
    if kind not in ('flood', 'earthquake'):
        raise PlanningError('Scenario must be cut, flood, earthquake or srlg.')
    center = event.get('center')
    if not isinstance(center, list) or len(center) != 2:
        raise PlanningError('center must be [latitude, longitude].')
    center = [number(center[0], 'lat', 40, 53), number(center[1], 'lon', 87, 121)]
    radius = number(event.get('radius_km', 80), 'radius_km', 1, 500)
    severity = number(event.get('severity', 1), 'severity', 0.5, 2)
    effective = radius * severity
    failed = sorted(e['id'] for e in edges if intersects_circle(e['geometry'], center, effective))
    return failed, {'kind': kind, 'center': center, 'radius_km': radius, 'severity': severity, 'effective_radius_km': effective}


def recovery(nodes, candidates, selected, failed, components):
    if len(components) == 1:
        return {'proposals': [], 'additional_capex_usd': 0, 'can_reconnect': True, 'message': 'Surviving infrastructure remains connected; A* rerouting is sufficient.'}
    membership = {node: i for i, comp in enumerate(components) for node in comp}
    selected_ids = {e['id'] for e in selected}
    cg = nx.Graph()
    cg.add_nodes_from(range(len(components)))
    by_id = {e['id']: e for e in candidates}
    for edge in candidates:
        a, b = membership[edge['source']], membership[edge['target']]
        if a == b:
            continue
        # Failed corridors may be physically restored; other candidates require construction.
        if edge['id'] in selected_ids and edge['id'] not in failed:
            continue
        if not cg.has_edge(a, b) or edge['cost_usd'] < cg[a][b]['cost_usd']:
            cg.add_edge(a, b, id=edge['id'], cost_usd=edge['cost_usd'], action='restore' if edge['id'] in failed else 'build')
    tree = nx.minimum_spanning_tree(cg, algorithm='prim', weight='cost_usd')
    proposals = [dict(e, source=by_id[e['id']]['source'], target=by_id[e['id']]['target']) for _, _, e in tree.edges(data=True)]
    return {'proposals': proposals, 'additional_capex_usd': round(sum(e['cost_usd'] for e in proposals), 2), 'can_reconnect': nx.is_connected(cg), 'message': 'Planning proposals only. Full replacement CAPEX is a proxy, not a repair quote. Restoration inside an active hazard requires clearance.'}


def simulate(nodes, candidates, selected, event, previous=(), reference='ub'):
    if set(previous) - {e['id'] for e in selected}:
        raise PlanningError('Previously failed IDs must belong to the selected topology.')
    impacted, zone = disaster_ids(selected, event)
    failed = sorted(set(previous) | set(impacted))
    g = graph(nodes, selected, failed)
    components = sorted((sorted(c) for c in nx.connected_components(g)), key=lambda c: (-len(c), c))
    reachable = nx.node_connected_component(g, reference)
    affected = sorted(set(g) - reachable)
    routes = []
    for node in nodes:
        if node['id'] == reference:
            continue
        before = route(nodes, selected, reference, node['id'])
        after = route(nodes, selected, reference, node['id'], failed)
        rerouted = after['reachable'] and before['edge_ids'] != after['edge_ids']
        routes.append({'destination': node['id'], 'before': before, 'after': after, 'rerouted': rerouted, 'delta_rtt_ms': round(after['modeled_rtt_ms'] - before['modeled_rtt_ms'], 5) if after['reachable'] and before['reachable'] else None})
    before_max = max((r['before']['modeled_rtt_ms'] for r in routes if r['before']['reachable']), default=0)
    after_max = max((r['after']['modeled_rtt_ms'] for r in routes if r['after']['reachable']), default=0)
    demand = sum(n.get('traffic_demand_mbps', 1) for n in nodes if n['id'] != reference)
    served = sum(n.get('traffic_demand_mbps', 1) for n in nodes if n['id'] in reachable and n['id'] != reference)
    return {'max_reference_rtt_before_ms': before_max, 'max_reference_rtt_after_ms': after_max, 'rtt_under_50': not affected and after_max < 50, 'failed_ids': failed, 'newly_impacted_ids': impacted, 'zone': zone, 'components': components, 'component_count': len(components), 'affected_nodes': affected, 'availability_pct': round(100 * len(reachable) / len(nodes), 2), 'demand_availability_pct': round(100 * served / demand, 2) if demand else 100, 'rerouted_count': sum(r['rerouted'] for r in routes), 'bridge_ids': tarjan_bridges(g), 'routes': routes, 'recovery': recovery(nodes, candidates, selected, failed, components), 'connected': len(components) == 1}
